package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.AppRootScreen
import com.example.ui.InpChatViewModel
import com.example.ui.screens.ActiveCallOverlay
import com.example.ui.screens.ChatDetailScreen
import com.example.ui.screens.MainWhatsAppScreen
import com.example.ui.screens.SocialAuthScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                InpChatApp()
            }
        }
    }
}

@Composable
fun InpChatApp(
    viewModel: InpChatViewModel = viewModel()
) {
    val rootScreen by viewModel.rootScreen.collectAsStateWithLifecycle()
    val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
    val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
    val chatRooms by viewModel.chatRooms.collectAsStateWithLifecycle()
    val statements by viewModel.officialStatements.collectAsStateWithLifecycle()
    val selectedChatRoomId by viewModel.selectedChatRoomId.collectAsStateWithLifecycle()
    val currentRoomMessages by viewModel.currentRoomMessages.collectAsStateWithLifecycle()
    val isSearchBarVisible by viewModel.isSearchBarVisible.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedChatFilter by viewModel.selectedChatFilter.collectAsStateWithLifecycle()
    val selectedStatementFilter by viewModel.selectedStatementFilter.collectAsStateWithLifecycle()
    val activeCallState by viewModel.activeCallState.collectAsStateWithLifecycle()
    val isRecordingVoice by viewModel.isRecordingVoice.collectAsStateWithLifecycle()
    val recordingSeconds by viewModel.recordingSeconds.collectAsStateWithLifecycle()
    val playingMessageId by viewModel.playingMessageId.collectAsStateWithLifecycle()
    val playbackProgress by viewModel.playbackProgress.collectAsStateWithLifecycle()
    val statusBanner by viewModel.statusBanner.collectAsStateWithLifecycle()

    val activeRoom = chatRooms.find { it.id == selectedChatRoomId }

    Box(modifier = Modifier.fillMaxSize()) {
        Crossfade(targetState = rootScreen, label = "root_navigation") { screen ->
            when (screen) {
                AppRootScreen.SPLASH -> {
                    SplashScreen(
                        onSplashComplete = { viewModel.onSplashFinished() }
                    )
                }

                AppRootScreen.SOCIAL_AUTH -> {
                    SocialAuthScreen(
                        initialProfile = userProfile,
                        onCompleteRegistration = { fullName, platform, handle, roleTitle, gov, leadership ->
                            viewModel.completeSocialRegistration(
                                fullName = fullName,
                                socialPlatform = platform,
                                socialHandle = handle,
                                roleTitle = roleTitle,
                                governorate = gov,
                                enableLeadership = leadership
                            )
                        }
                    )
                }

                AppRootScreen.MAIN_HOME -> {
                    if (activeRoom != null) {
                        ChatDetailScreen(
                            room = activeRoom,
                            messages = currentRoomMessages,
                            userProfile = userProfile,
                            isRecordingVoice = isRecordingVoice,
                            recordingSeconds = recordingSeconds,
                            playingMessageId = playingMessageId,
                            playbackProgress = playbackProgress,
                            onBack = { viewModel.closeChatRoom() },
                            onSendTextOrLink = { text ->
                                viewModel.sendTextOrLinkMessage(activeRoom, text)
                            },
                            onSendRichLink = { url, title, comment ->
                                viewModel.sendRichLinkMessage(activeRoom, url, title, comment)
                            },
                            onSendMedia = { caption, uri, isVideo ->
                                viewModel.sendMediaMessage(activeRoom, caption, uri, isVideo)
                            },
                            onStartVoiceRecording = { viewModel.startVoiceRecording() },
                            onCancelVoiceRecording = { viewModel.cancelVoiceRecording() },
                            onFinishVoiceRecording = {
                                viewModel.finishAndSendVoiceRecording(activeRoom)
                            },
                            onToggleVoicePlayback = { msg ->
                                viewModel.toggleVoiceNotePlayback(msg)
                            },
                            onToggleReaction = { msg, emoji ->
                                viewModel.toggleMessageReaction(msg, emoji)
                            },
                            onStartVoiceCall = { viewModel.startCall(activeRoom, isVideoCall = false) },
                            onStartVideoCall = { viewModel.startCall(activeRoom, isVideoCall = true) },
                            onTogglePinRoom = { viewModel.togglePinRoom(activeRoom) },
                            onToggleMuteRoom = { viewModel.toggleMuteRoom(activeRoom) }
                        )
                    } else {
                        MainWhatsAppScreen(
                            selectedTab = selectedTab,
                            chatRooms = chatRooms,
                            statements = statements,
                            userProfile = userProfile,
                            isSearchBarVisible = isSearchBarVisible,
                            searchQuery = searchQuery,
                            selectedChatFilter = selectedChatFilter,
                            selectedStatementFilter = selectedStatementFilter,
                            statusBanner = statusBanner,
                            onSelectTab = { viewModel.selectTab(it) },
                            onToggleSearchBar = { viewModel.toggleSearchBar() },
                            onSearchQueryChange = { viewModel.updateSearchQuery(it) },
                            onChatFilterSelected = { viewModel.setChatFilter(it) },
                            onStatementFilterSelected = { viewModel.setStatementFilter(it) },
                            onOpenChatRoom = { viewModel.openChatRoom(it) },
                            onTogglePinRoom = { viewModel.togglePinRoom(it) },
                            onStartVoiceCall = { room -> viewModel.startCall(room, isVideoCall = false) },
                            onStartVideoCall = { room -> viewModel.startCall(room, isVideoCall = true) },
                            onCreateNewRoom = { title, subtitle, category, handle, platform, count ->
                                viewModel.createNewRoom(title, subtitle, category, handle, platform, count)
                            },
                            onPublishStatement = { title, cat, content, pinned, refNum ->
                                viewModel.publishOfficialStatement(title, cat, content, pinned, refNum)
                            },
                            onToggleStatementLike = { viewModel.toggleStatementLike(it) },
                            onToggleStatementPin = { viewModel.toggleStatementPin(it) },
                            onDeleteStatement = { viewModel.deleteStatement(it) },
                            onShareStatementToRoom = { stmt, room ->
                                viewModel.shareStatementToRoom(stmt, room)
                            },
                            onEditSocialAccount = { viewModel.openSocialAuthEditor() },
                            onUpdateProfile = { updated, msg ->
                                viewModel.updateProfileSettings(updated, msg)
                            },
                            onResetDemoData = { viewModel.resetDemoData() }
                        )
                    }
                }
            }
        }

        // Fullscreen Voice / Video Call Overlay when a call is active
        activeCallState?.let { callState ->
            ActiveCallOverlay(
                callState = callState,
                onToggleMute = { viewModel.toggleCallMute() },
                onToggleSpeaker = { viewModel.toggleCallSpeaker() },
                onToggleCamera = { viewModel.toggleCallCamera() },
                onEndCall = { viewModel.endActiveCall() }
            )
        }
    }
}
