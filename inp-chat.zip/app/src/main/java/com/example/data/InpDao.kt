package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface InpDao {

    @Query("SELECT * FROM chat_rooms ORDER BY isPinned DESC, lastUpdatedEpoch DESC")
    fun observeChatRooms(): Flow<List<ChatRoomEntity>>

    @Query("SELECT COUNT(*) FROM chat_rooms")
    suspend fun getChatRoomsCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChatRoom(room: ChatRoomEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChatRooms(rooms: List<ChatRoomEntity>): List<Long>

    @Update
    suspend fun updateChatRoom(room: ChatRoomEntity)

    @Query("UPDATE chat_rooms SET unreadCount = 0 WHERE id = :roomId")
    suspend fun markRoomAsRead(roomId: Long)

    @Query("UPDATE chat_rooms SET isPinned = :pinned WHERE id = :roomId")
    suspend fun setRoomPinned(roomId: Long, pinned: Boolean)

    @Query("UPDATE chat_rooms SET isMuted = :muted WHERE id = :roomId")
    suspend fun setRoomMuted(roomId: Long, muted: Boolean)

    @Query("SELECT * FROM messages WHERE chatRoomId = :roomId ORDER BY timestampEpoch ASC")
    fun observeMessagesForRoom(roomId: Long): Flow<List<MessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: MessageEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessages(messages: List<MessageEntity>)

    @Query("UPDATE messages SET reactionEmoji = :emoji WHERE id = :messageId")
    suspend fun updateMessageReaction(messageId: Long, emoji: String)

    @Query("DELETE FROM messages WHERE id = :messageId")
    suspend fun deleteMessage(messageId: Long)

    @Query("SELECT * FROM official_statements ORDER BY isPinned DESC, timestampEpoch DESC")
    fun observeOfficialStatements(): Flow<List<OfficialStatementEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStatement(statement: OfficialStatementEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStatements(statements: List<OfficialStatementEntity>)

    @Update
    suspend fun updateStatement(statement: OfficialStatementEntity)

    @Query("DELETE FROM official_statements WHERE id = :statementId")
    suspend fun deleteStatement(statementId: Long)

    @Query("DELETE FROM chat_rooms")
    suspend fun clearAllRooms()

    @Query("DELETE FROM messages")
    suspend fun clearAllMessages()

    @Query("DELETE FROM official_statements")
    suspend fun clearAllStatements()
}
