package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        ChatRoomEntity::class,
        MessageEntity::class,
        OfficialStatementEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class InpDatabase : RoomDatabase() {
    abstract fun inpDao(): InpDao

    companion object {
        @Volatile
        private var INSTANCE: InpDatabase? = null

        fun getInstance(context: Context): InpDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    InpDatabase::class.java,
                    "inp_party_chat.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
