package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class SocialPlatform(val displayName: String, val baseUrl: String) {
    TIKTOK("TikTok", "https://www.tiktok.com/@"),
    INSTAGRAM("Instagram", "https://www.instagram.com/")
}

enum class ChatCategory(val labelAr: String) {
    OFFICIAL_GROUP("مجموعة رسمية"),
    CADRE_GROUP("غرفة كوادر"),
    DIRECT_CHAT("محادثة خاصة")
}

enum class MessageType {
    TEXT,
    VOICE,
    IMAGE,
    VIDEO,
    LINK,
    CALL_LOG,
    OFFICIAL_SHARE
}

data class UserProfile(
    val fullName: String = "كادر الهوية القومية",
    val socialPlatform: SocialPlatform = SocialPlatform.TIKTOK,
    val socialHandle: String = "@inp.iraq",
    val roleTitle: String = "كادر متقدم - المكتب المركزي",
    val governorate: String = "بغداد",
    val bio: String = "العراق أولاً | حزب الهوية القومية العراقية INP",
    val isLeadershipMode: Boolean = true,
    val readReceiptsEnabled: Boolean = true,
    val hideLastSeen: Boolean = false,
    val appLockEnabled: Boolean = false,
    val appLockPin: String = "1920",
    val chatWallpaperHex: String = "#ECE5DD",
    val isRegistered: Boolean = false
)

@Entity(tableName = "chat_rooms")
data class ChatRoomEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val subtitle: String,
    val category: String, // ChatCategory.name
    val avatarColorHex: String,
    val membersCount: Int,
    val socialLinkHandle: String,
    val socialPlatform: String, // SocialPlatform.name
    val lastMessagePreview: String,
    val lastMessageTime: String,
    val lastUpdatedEpoch: Long,
    val unreadCount: Int = 0,
    val isPinned: Boolean = false,
    val isMuted: Boolean = false,
    val isOfficialVerified: Boolean = true
)

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val chatRoomId: Long,
    val senderName: String,
    val senderSocialHandle: String,
    val senderPlatform: String, // SocialPlatform.name
    val senderRole: String,
    val content: String,
    val messageType: String, // MessageType.name
    val mediaUri: String = "",
    val linkUrl: String = "",
    val linkTitle: String = "",
    val voiceDurationSec: Int = 0,
    val waveformSeed: Int = 42,
    val isOutgoing: Boolean,
    val timestampText: String,
    val timestampEpoch: Long = System.currentTimeMillis(),
    val isPinned: Boolean = false,
    val reactionEmoji: String = ""
)

@Entity(tableName = "official_statements")
data class OfficialStatementEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val category: String, // بيان رسمي | تعميم تنظيمي | البرنامج السياسي | خبر عاجل
    val content: String,
    val authorName: String,
    val authorRole: String,
    val publishedTime: String,
    val timestampEpoch: Long = System.currentTimeMillis(),
    val isPinned: Boolean = false,
    val likesCount: Int = 0,
    val isLikedByMe: Boolean = false,
    val referenceNumber: String = ""
)
