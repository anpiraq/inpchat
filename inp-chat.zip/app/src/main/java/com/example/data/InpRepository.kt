package com.example.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class InpRepository(
    context: Context,
    private val dao: InpDao
) {
    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences("inp_user_prefs", Context.MODE_PRIVATE)

    private val _userProfile = MutableStateFlow(loadProfileFromPrefs())
    val userProfile: StateFlow<UserProfile> = _userProfile.asStateFlow()

    val chatRooms: Flow<List<ChatRoomEntity>> = dao.observeChatRooms()
    val officialStatements: Flow<List<OfficialStatementEntity>> = dao.observeOfficialStatements()

    fun observeMessages(roomId: Long): Flow<List<MessageEntity>> = dao.observeMessagesForRoom(roomId)

    private fun loadProfileFromPrefs(): UserProfile {
        val platformStr = prefs.getString("social_platform", SocialPlatform.TIKTOK.name)
            ?: SocialPlatform.TIKTOK.name
        val platform = try {
            SocialPlatform.valueOf(platformStr)
        } catch (_: Exception) {
            SocialPlatform.TIKTOK
        }
        return UserProfile(
            fullName = prefs.getString("full_name", "ذو الفقار العراقي") ?: "ذو الفقار العراقي",
            socialPlatform = platform,
            socialHandle = prefs.getString("social_handle", "@inp.iraq") ?: "@inp.iraq",
            roleTitle = prefs.getString("role_title", "كادر متقدم - المكتب المركزي")
                ?: "كادر متقدم - المكتب المركزي",
            governorate = prefs.getString("governorate", "بغداد") ?: "بغداد",
            bio = prefs.getString("bio", "العراق أولاً | حزب الهوية القومية العراقية INP")
                ?: "العراق أولاً | حزب الهوية القومية العراقية INP",
            isLeadershipMode = prefs.getBoolean("is_leadership_mode", true),
            readReceiptsEnabled = prefs.getBoolean("read_receipts", true),
            hideLastSeen = prefs.getBoolean("hide_last_seen", false),
            appLockEnabled = prefs.getBoolean("app_lock_enabled", false),
            appLockPin = prefs.getString("app_lock_pin", "1920") ?: "1920",
            chatWallpaperHex = prefs.getString("chat_wallpaper_hex", "#ECE5DD") ?: "#ECE5DD",
            isRegistered = prefs.getBoolean("is_registered", false)
        )
    }

    fun updateUserProfile(updated: UserProfile) {
        val cleanHandle = if (updated.socialHandle.startsWith("@")) {
            updated.socialHandle.trim()
        } else {
            "@${updated.socialHandle.trim()}"
        }
        val normalized = updated.copy(socialHandle = cleanHandle)
        prefs.edit()
            .putString("full_name", normalized.fullName)
            .putString("social_platform", normalized.socialPlatform.name)
            .putString("social_handle", normalized.socialHandle)
            .putString("role_title", normalized.roleTitle)
            .putString("governorate", normalized.governorate)
            .putString("bio", normalized.bio)
            .putBoolean("is_leadership_mode", normalized.isLeadershipMode)
            .putBoolean("read_receipts", normalized.readReceiptsEnabled)
            .putBoolean("hide_last_seen", normalized.hideLastSeen)
            .putBoolean("app_lock_enabled", normalized.appLockEnabled)
            .putString("app_lock_pin", normalized.appLockPin)
            .putString("chat_wallpaper_hex", normalized.chatWallpaperHex)
            .putBoolean("is_registered", normalized.isRegistered)
            .apply()
        _userProfile.value = normalized
    }

    suspend fun ensureSeeded() {
        if (dao.getChatRoomsCount() > 0) return
        seedInitialPartyData()
    }

    suspend fun resetAndReseedAll() {
        dao.clearAllMessages()
        dao.clearAllRooms()
        dao.clearAllStatements()
        seedInitialPartyData()
    }

    suspend fun markRoomRead(roomId: Long) {
        dao.markRoomAsRead(roomId)
    }

    suspend fun togglePinRoom(room: ChatRoomEntity) {
        dao.setRoomPinned(room.id, !room.isPinned)
    }

    suspend fun toggleMuteRoom(room: ChatRoomEntity) {
        dao.setRoomMuted(room.id, !room.isMuted)
    }

    suspend fun createNewChatRoom(
        title: String,
        subtitle: String,
        category: ChatCategory,
        socialHandle: String,
        socialPlatform: SocialPlatform,
        membersCount: Int
    ): Long {
        val cleanHandle = if (socialHandle.startsWith("@")) socialHandle else "@$socialHandle"
        val now = System.currentTimeMillis()
        val timeStr = formatCurrentTime()
        val palette = listOf("#8B1A20", "#075E54", "#1D63B8", "#128C7E", "#6A1B4D")
        val colorHex = palette[title.hashCode().let { if (it < 0) -it else it } % palette.size]

        val roomId = dao.insertChatRoom(
            ChatRoomEntity(
                title = title,
                subtitle = subtitle,
                category = category.name,
                avatarColorHex = colorHex,
                membersCount = membersCount,
                socialLinkHandle = cleanHandle,
                socialPlatform = socialPlatform.name,
                lastMessagePreview = "تم إنشاء غرفة التواصل الحزبية • العراق أولاً",
                lastMessageTime = timeStr,
                lastUpdatedEpoch = now,
                unreadCount = 0,
                isPinned = category == ChatCategory.OFFICIAL_GROUP,
                isOfficialVerified = true
            )
        )

        dao.insertMessage(
            MessageEntity(
                chatRoomId = roomId,
                senderName = "الأمانة العامة - INP",
                senderSocialHandle = cleanHandle,
                senderPlatform = socialPlatform.name,
                senderRole = "النظام المركزي",
                content = "أهلاً بكم في \"$title\" التابعة لحزب الهوية القومية العراقية (INP). جميع المحادثات مشفرة ومخصصة للتنسيق الحزبي والوطني.",
                messageType = MessageType.TEXT.name,
                isOutgoing = false,
                timestampText = timeStr,
                timestampEpoch = now
            )
        )
        return roomId
    }

    suspend fun sendMessage(
        room: ChatRoomEntity,
        content: String,
        type: MessageType = MessageType.TEXT,
        mediaUri: String = "",
        linkUrl: String = "",
        linkTitle: String = "",
        voiceDurationSec: Int = 0
    ) {
        val profile = _userProfile.value
        val now = System.currentTimeMillis()
        val timeStr = formatCurrentTime()

        dao.insertMessage(
            MessageEntity(
                chatRoomId = room.id,
                senderName = profile.fullName,
                senderSocialHandle = profile.socialHandle,
                senderPlatform = profile.socialPlatform.name,
                senderRole = profile.roleTitle,
                content = content,
                messageType = type.name,
                mediaUri = mediaUri,
                linkUrl = linkUrl,
                linkTitle = linkTitle,
                voiceDurationSec = voiceDurationSec,
                waveformSeed = (now % 97).toInt() + 11,
                isOutgoing = true,
                timestampText = timeStr,
                timestampEpoch = now
            )
        )

        val preview = when (type) {
            MessageType.VOICE -> "🎤 رسالة صوتية (${formatDuration(voiceDurationSec)})"
            MessageType.IMAGE -> "📷 صورة مرفقة: $content"
            MessageType.VIDEO -> "🎬 فيديو مرفق: $content"
            MessageType.LINK -> "🔗 رابط: ${linkTitle.ifBlank { content }}"
            MessageType.CALL_LOG -> "📞 $content"
            MessageType.OFFICIAL_SHARE -> "📢 بيان رسمي: $content"
            MessageType.TEXT -> content
        }

        dao.updateChatRoom(
            room.copy(
                lastMessagePreview = preview,
                lastMessageTime = timeStr,
                lastUpdatedEpoch = now,
                unreadCount = 0
            )
        )
    }

    suspend fun generateCadreAutoReply(room: ChatRoomEntity, userMessageType: MessageType) {
        val now = System.currentTimeMillis() + 500
        val timeStr = formatCurrentTime()
        val replyPair = when {
            room.title.contains("المكتب السياسي") -> Pair(
                "د. حيدر العراقي",
                "@dr.haider.inp" to "تم استلام مشاركتكم في المكتب السياسي المركزي، بارك الله بجهودكم الوطنية لخدمة العراق أولاً."
            )
            room.title.contains("الإعلامية") -> Pair(
                "أ. زينب الكناني",
                "@zainab.inp.media" to "عاشت الأيادي! سنقوم بتعميم هذه المادة عبر حسابات الحزب الرسمية في تيك توك وإنستغرام."
            )
            room.title.contains("كوادر بغداد") -> Pair(
                "م. مصطفى العبيدي",
                "@mustafa.baghdad.inp" to "تحية طيبة من مكتب بغداد الرصافة، الكوادر الميدانية على أتم الجاهزية للتنفيذ."
            )
            userMessageType == MessageType.VOICE -> Pair(
                room.title,
                room.socialLinkHandle to "تم الاستماع للرسالة الصوتية بوضوح، نتفق تماماً مع الطرح التنظيمي."
            )
            else -> Pair(
                "مسؤول التنسيق - INP",
                room.socialLinkHandle to "شكراً لتواصلكم عبر منصة INP Chat، معاً لترسيخ الهوية القومية العراقية."
            )
        }

        dao.insertMessage(
            MessageEntity(
                chatRoomId = room.id,
                senderName = replyPair.first,
                senderSocialHandle = replyPair.second.first,
                senderPlatform = room.socialPlatform,
                senderRole = "قيادة / تنسيق الحزب",
                content = replyPair.second.second,
                messageType = MessageType.TEXT.name,
                isOutgoing = false,
                timestampText = timeStr,
                timestampEpoch = now
            )
        )

        dao.updateChatRoom(
            room.copy(
                lastMessagePreview = "${replyPair.first}: ${replyPair.second.second}",
                lastMessageTime = timeStr,
                lastUpdatedEpoch = now
            )
        )
    }

    suspend fun toggleMessageReaction(message: MessageEntity, emoji: String) {
        val next = if (message.reactionEmoji == emoji) "" else emoji
        dao.updateMessageReaction(message.id, next)
    }

    suspend fun publishOfficialStatement(
        title: String,
        category: String,
        content: String,
        isPinned: Boolean,
        referenceNumber: String
    ) {
        val profile = _userProfile.value
        val now = System.currentTimeMillis()
        dao.insertStatement(
            OfficialStatementEntity(
                title = title,
                category = category,
                content = content,
                authorName = "${profile.fullName} (${profile.socialHandle})",
                authorRole = profile.roleTitle,
                publishedTime = "الآن • ${formatCurrentTime()}",
                timestampEpoch = now,
                isPinned = isPinned,
                likesCount = 1,
                isLikedByMe = true,
                referenceNumber = referenceNumber.ifBlank { "INP-${(now % 900) + 100}" }
            )
        )
    }

    suspend fun toggleStatementLike(statement: OfficialStatementEntity) {
        val liked = !statement.isLikedByMe
        val delta = if (liked) 1 else -1
        dao.updateStatement(
            statement.copy(
                isLikedByMe = liked,
                likesCount = (statement.likesCount + delta).coerceAtLeast(0)
            )
        )
    }

    suspend fun toggleStatementPin(statement: OfficialStatementEntity) {
        dao.updateStatement(statement.copy(isPinned = !statement.isPinned))
    }

    suspend fun deleteStatement(statementId: Long) {
        dao.deleteStatement(statementId)
    }

    private fun formatCurrentTime(): String {
        val sdf = SimpleDateFormat("hh:mm a", Locale("ar"))
        return sdf.format(Date())
    }

    private fun formatDuration(seconds: Int): String {
        val m = seconds / 60
        val s = seconds % 60
        return String.format(Locale.US, "%02d:%02d", m, s)
    }

    private suspend fun seedInitialPartyData() {
        val now = System.currentTimeMillis()

        val rooms = listOf(
            ChatRoomEntity(
                id = 1,
                title = "المكتب السياسي المركزي - INP",
                subtitle = "القيادة العامة • القرارات والبيانات السيادية",
                category = ChatCategory.OFFICIAL_GROUP.name,
                avatarColorHex = "#8B1A20",
                membersCount = 148,
                socialLinkHandle = "@inp.iraq.official",
                socialPlatform = SocialPlatform.TIKTOK.name,
                lastMessagePreview = "📢 تعميم رقم (14): توحيد الخطاب الإعلامي تحت شعار العراق أولاً",
                lastMessageTime = "10:45 ص",
                lastUpdatedEpoch = now - 60_000L,
                unreadCount = 3,
                isPinned = true,
                isOfficialVerified = true
            ),
            ChatRoomEntity(
                id = 2,
                title = "كوادر بغداد والمحافظات",
                subtitle = "التنسيق الميداني للمكاتب التنظيمية في 18 محافظة",
                category = ChatCategory.CADRE_GROUP.name,
                avatarColorHex = "#075E54",
                membersCount = 620,
                socialLinkHandle = "@inp_cadres_iq",
                socialPlatform = SocialPlatform.INSTAGRAM.name,
                lastMessagePreview = "🎤 رسالة صوتية من مكتب البصرة حول المؤتمر التنظيمي",
                lastMessageTime = "10:18 ص",
                lastUpdatedEpoch = now - 180_000L,
                unreadCount = 5,
                isPinned = true,
                isOfficialVerified = true
            ),
            ChatRoomEntity(
                id = 3,
                title = "اللجنة الإعلامية (TikTok & Instagram)",
                subtitle = "فريق النشر الرقمي وصناعة المحتوى الوطني",
                category = ChatCategory.CADRE_GROUP.name,
                avatarColorHex = "#1D63B8",
                membersCount = 94,
                socialLinkHandle = "@inp.media.iq",
                socialPlatform = SocialPlatform.TIKTOK.name,
                lastMessagePreview = "🔗 رابط البث المباشر الرسمي للحزب على تيك توك وإنستغرام",
                lastMessageTime = "09:30 ص",
                lastUpdatedEpoch = now - 420_000L,
                unreadCount = 1,
                isPinned = false,
                isOfficialVerified = true
            ),
            ChatRoomEntity(
                id = 4,
                title = "ملتقى الشباب والطلبة الوطني - INP",
                subtitle = "تجمع شباب الهوية القومية العراقية والجامعات",
                category = ChatCategory.OFFICIAL_GROUP.name,
                avatarColorHex = "#128C7E",
                membersCount = 1240,
                socialLinkHandle = "@inp.youth.iq",
                socialPlatform = SocialPlatform.INSTAGRAM.name,
                lastMessagePreview = "📷 صور الندوة الحوارية في جامعة بغداد: الهوية الوطنية الجامعة",
                lastMessageTime = "أمس",
                lastUpdatedEpoch = now - 3_600_000L,
                unreadCount = 0,
                isPinned = false,
                isOfficialVerified = true
            ),
            ChatRoomEntity(
                id = 5,
                title = "د. حيدر العراقي - مسؤول التنظيم",
                subtitle = "مسؤول ملف التنظيم والعضوية المركزية",
                category = ChatCategory.DIRECT_CHAT.name,
                avatarColorHex = "#590D12",
                membersCount = 2,
                socialLinkHandle = "@dr.haider.inp",
                socialPlatform = SocialPlatform.TIKTOK.name,
                lastMessagePreview = "📞 مكالمة صوتية واردة • 04:15",
                lastMessageTime = "أمس",
                lastUpdatedEpoch = now - 7_200_000L,
                unreadCount = 0,
                isPinned = false,
                isOfficialVerified = true
            ),
            ChatRoomEntity(
                id = 6,
                title = "أ. زينب الكناني - المكتب الإعلامي",
                subtitle = "منسقة البيانات الرسمية والتواصل الجماهيري",
                category = ChatCategory.DIRECT_CHAT.name,
                avatarColorHex = "#2B5876",
                membersCount = 2,
                socialLinkHandle = "@zainab.inp.media",
                socialPlatform = SocialPlatform.INSTAGRAM.name,
                lastMessagePreview = "تم تجهيز التصميم الجديد لشعار INP Chat بدقة عالية",
                lastMessageTime = "أمس",
                lastUpdatedEpoch = now - 14_400_000L,
                unreadCount = 0,
                isPinned = false,
                isOfficialVerified = true
            )
        )
        dao.insertChatRooms(rooms)

        val seededMessages = listOf(
            // Room 1: Central Political Bureau
            MessageEntity(
                chatRoomId = 1,
                senderName = "الأمانة العامة - INP",
                senderSocialHandle = "@inp.iraq.official",
                senderPlatform = SocialPlatform.TIKTOK.name,
                senderRole = "القيادة المركزية",
                content = "بسم الله الرحمن الرحيم\nنرحب بكافة أعضاء وكوادر حزب الهوية القومية العراقية (INP) في المنصة الرسمية المشفرة. شعارنا الدائم: العراق أولاً.",
                messageType = MessageType.TEXT.name,
                isOutgoing = false,
                timestampText = "09:15 ص",
                timestampEpoch = now - 500_000L,
                reactionEmoji = "🇮🇶"
            ),
            MessageEntity(
                chatRoomId = 1,
                senderName = "د. حيدر العراقي",
                senderSocialHandle = "@dr.haider.inp",
                senderPlatform = SocialPlatform.TIKTOK.name,
                senderRole = "مسؤول التنظيم المركزي",
                content = "رسالة صوتية توجيهية إلى مسؤولي المكاتب في بغداد والمحافظات حول آلية استقبال الأعضاء الجدد.",
                messageType = MessageType.VOICE.name,
                mediaUri = "simulated_voice://seed_1",
                voiceDurationSec = 38,
                waveformSeed = 27,
                isOutgoing = false,
                timestampText = "09:40 ص",
                timestampEpoch = now - 400_000L,
                reactionEmoji = "👍"
            ),
            MessageEntity(
                chatRoomId = 1,
                senderName = "ذو الفقار العراقي",
                senderSocialHandle = "@inp.iraq",
                senderPlatform = SocialPlatform.TIKTOK.name,
                senderRole = "كادر متقدم - المكتب المركزي",
                content = "تم تعميم التوجيهات على كافة اللجان التنظيمية والإعلامية، وسنوافيكم بالتقارير الميدانية تباعاً.",
                messageType = MessageType.TEXT.name,
                isOutgoing = true,
                timestampText = "10:10 ص",
                timestampEpoch = now - 200_000L
            ),
            MessageEntity(
                chatRoomId = 1,
                senderName = "الأمانة العامة - INP",
                senderSocialHandle = "@inp.iraq.official",
                senderPlatform = SocialPlatform.TIKTOK.name,
                senderRole = "القيادة المركزية",
                content = "تعميم رقم (14): توحيد الخطاب الإعلامي تحت شعار العراق أولاً والتركيز على ملف السيادة والاقتصاد الوطني.",
                messageType = MessageType.OFFICIAL_SHARE.name,
                linkTitle = "تعميم تنظيمي عاجل • INP-014",
                isOutgoing = false,
                timestampText = "10:45 ص",
                timestampEpoch = now - 60_000L,
                reactionEmoji = "✅"
            ),

            // Room 2: Baghdad & Governorates Cadres
            MessageEntity(
                chatRoomId = 2,
                senderName = "م. مصطفى العبيدي",
                senderSocialHandle = "@mustafa.baghdad.inp",
                senderPlatform = SocialPlatform.INSTAGRAM.name,
                senderRole = "منسق مكتب بغداد",
                content = "اجتماع موسع لكوادر الحزب في جانب الكرخ والرصافة للتحضير للمؤتمر العام.",
                messageType = MessageType.IMAGE.name,
                mediaUri = "party_banner_meeting",
                isOutgoing = false,
                timestampText = "09:50 ص",
                timestampEpoch = now - 300_000L,
                reactionEmoji = "👏"
            ),
            MessageEntity(
                chatRoomId = 2,
                senderName = "الشيخ علي التميمي",
                senderSocialHandle = "@ali.basra.inp",
                senderPlatform = SocialPlatform.TIKTOK.name,
                senderRole = "منسق مكتب البصرة",
                content = "إحاطة صوتية من مكتب محافظة البصرة حول الفعاليات الجماهيرية.",
                messageType = MessageType.VOICE.name,
                mediaUri = "simulated_voice://seed_2",
                voiceDurationSec = 52,
                waveformSeed = 64,
                isOutgoing = false,
                timestampText = "10:18 ص",
                timestampEpoch = now - 180_000L
            ),

            // Room 3: Media Committee
            MessageEntity(
                chatRoomId = 3,
                senderName = "أ. زينب الكناني",
                senderSocialHandle = "@zainab.inp.media",
                senderPlatform = SocialPlatform.INSTAGRAM.name,
                senderRole = "مسؤولة اللجنة الإعلامية",
                content = "يرجى من جميع الكوادر مشاركة رابط الصفحة الرسمية لحزب الهوية القومية العراقية على تيك توك وإنستغرام في حساباتهم:",
                messageType = MessageType.LINK.name,
                linkUrl = "https://www.tiktok.com/@inp.iraq.official",
                linkTitle = "الحساب الرسمي لحزب الهوية القومية العراقية (INP) على TikTok",
                isOutgoing = false,
                timestampText = "09:10 ص",
                timestampEpoch = now - 500_000L
            ),
            MessageEntity(
                chatRoomId = 3,
                senderName = "أ. زينب الكناني",
                senderSocialHandle = "@zainab.inp.media",
                senderPlatform = SocialPlatform.INSTAGRAM.name,
                senderRole = "مسؤولة اللجنة الإعلامية",
                content = "الفيديو التعريفي الرسمي بالحزب وشعار (العراق أولاً) جاهز للنشر.",
                messageType = MessageType.VIDEO.name,
                mediaUri = "party_promo_video",
                voiceDurationSec = 95,
                isOutgoing = false,
                timestampText = "09:30 ص",
                timestampEpoch = now - 420_000L,
                reactionEmoji = "🔥"
            ),

            // Room 4: Youth Committee
            MessageEntity(
                chatRoomId = 4,
                senderName = "أحمد الخفاجي",
                senderSocialHandle = "@ahmed.youth.inp",
                senderPlatform = SocialPlatform.INSTAGRAM.name,
                senderRole = "رئيس ملتقى الشباب",
                content = "صور الندوة الحوارية في جامعة بغداد حول دور الشباب في حماية الهوية الوطنية العراقية.",
                messageType = MessageType.IMAGE.name,
                mediaUri = "party_youth_seminar",
                isOutgoing = false,
                timestampText = "أمس",
                timestampEpoch = now - 3_600_000L
            ),

            // Room 5: Dr. Haider Direct Chat
            MessageEntity(
                chatRoomId = 5,
                senderName = "د. حيدر العراقي - مسؤول التنظيم",
                senderSocialHandle = "@dr.haider.inp",
                senderPlatform = SocialPlatform.TIKTOK.name,
                senderRole = "مسؤول التنظيم المركزي",
                content = "مكالمة صوتية واردة • المدة 04:15",
                messageType = MessageType.CALL_LOG.name,
                isOutgoing = false,
                timestampText = "أمس",
                timestampEpoch = now - 7_200_000L
            ),

            // Room 6: Zainab Direct Chat
            MessageEntity(
                chatRoomId = 6,
                senderName = "أ. زينب الكناني - المكتب الإعلامي",
                senderSocialHandle = "@zainab.inp.media",
                senderPlatform = SocialPlatform.INSTAGRAM.name,
                senderRole = "المكتب الإعلامي",
                content = "تم تجهيز التصميم الجديد لشعار INP Chat بدقة عالية واعتماد الهوية البصرية الجديدة.",
                messageType = MessageType.TEXT.name,
                isOutgoing = false,
                timestampText = "أمس",
                timestampEpoch = now - 14_400_000L
            )
        )
        dao.insertMessages(seededMessages)

        val statements = listOf(
            OfficialStatementEntity(
                id = 1,
                title = "المرتكزات الأساسية للبرنامج السياسي لحزب الهوية القومية العراقية (INP)",
                category = "البرنامج السياسي",
                content = """
                    انطلاقاً من شعارنا الثابت «العراق أولاً»، يعلن حزب الهوية القومية العراقية (INP) مرتكزات برنامجه السياسي والوطني الشامل:
                    
                    1. السيادة الوطنية الكاملة: الحفاظ على وحدة العراق أرضاً وشعباً، واستقلالية القرار الوطني العراقي بعيداً عن أي أجندات خارجية.
                    2. الهوية القومية والوطنية الجامعة: تعزيز الانتماء للعراق وتاريخه الحضاري العريق، وترسيخ المواطنة المتساوية بين جميع أبناء الشعب.
                    3. الاقتصاد الإنتاجي والتنمية المستدامة: دعم الصناعة الوطنية والقطاع الزراعي، وتقليل الاعتماد الأحادي، وتوفير فرص عمل حقيقية للشباب والخريجين.
                    4. سيادة القانون وبناء المؤسسات: مكافحة الفساد الإداري والمالي، وأتمتة مؤسسات الدولة لضمان الشفافية والعدالة الاجتماعية.
                    5. تمكين الشباب والمرأة: إشراك الكفاءات الشبابية والنسوية في مواقع صنع القرار السياسي والتنفيذي.
                """.trimIndent(),
                authorName = "الأمانة العامة - المكتب السياسي",
                authorRole = "حزب الهوية القومية العراقية - INP",
                publishedTime = "مثبت دائماً • الوثيقة التأسيسية",
                timestampEpoch = now - 10_000L,
                isPinned = true,
                likesCount = 842,
                isLikedByMe = true,
                referenceNumber = "INP-PROG-01"
            ),
            OfficialStatementEntity(
                id = 2,
                title = "تعميم تنظيمي رقم (14) بشأن توحيد النشر الرقمي عبر تيك توك وإنستغرام",
                category = "تعميم تنظيمي",
                content = """
                    إلى كافة المكاتب التنظيمية واللجان الإعلامية والكوادر في بغداد والمحافظات:
                    
                    تقرر اعتماد منصة (INP Chat) نافذةً رسميةً وحيدةً لتلقي التعاميم والبيانات الصادرة عن المكتب السياسي. كما نهيب بكافة الأعضاء ربط حساباتهم الرسمية في (TikTok) و(Instagram) بالمنصة للمساهمة الفاعلة في الحملات الإعلامية الوطنية تحت وسم #العراق_أولاً و #حزب_الهوية_القومية_العراقية.
                """.trimIndent(),
                authorName = "دائرة التنظيم والإعلام المركزي",
                authorRole = "قيادة الحزب",
                publishedTime = "اليوم • 10:30 ص",
                timestampEpoch = now - 50_000L,
                isPinned = true,
                likesCount = 319,
                isLikedByMe = false,
                referenceNumber = "INP-CIRC-14"
            ),
            OfficialStatementEntity(
                id = 3,
                title = "بيان رسمي: دعم الكفاءات الشبابية وإطلاق مبادرة التدريب الوطني",
                category = "بيان رسمي",
                content = """
                    يؤكد حزب الهوية القومية العراقية (INP) أن الشباب العراقي هم الركيزة الأولى لبناء دولة المؤسسات الحديثة. وعليه، يعلن المكتب السياسي عن إطلاق سلسلة ورش عمل وندوات وطنية في كافة المحافظات لتأهيل القيادات الشابة في مجالات الإدارة العامة، الإعلام الرقمي، والاقتصاد الوطني.
                """.trimIndent(),
                authorName = "المتحدث الرسمي باسم الحزب",
                authorRole = "المكتب السياسي - بغداد",
                publishedTime = "أمس • 08:15 م",
                timestampEpoch = now - 90_000L,
                isPinned = false,
                likesCount = 215,
                isLikedByMe = true,
                referenceNumber = "INP-STMT-88"
            ),
            OfficialStatementEntity(
                id = 4,
                title = "خبر عاجل: انعقاد الملتقى التنظيمي الدوري لمسؤولي مكاتب المحافظات",
                category = "خبر عاجل",
                content = """
                    عقد المكتب السياسي المركزي لحزب الهوية القومية العراقية اجتماعاً موسعاً ضم منسقي المكاتب في المحافظات لمناقشة خطة العمل الميداني للفصل القادم وتعزيز التواصل المباشر مع المواطنين.
                """.trimIndent(),
                authorName = "اللجنة الإعلامية المركزية",
                authorRole = "تغطية خاصة - INP",
                publishedTime = "قبل يومين",
                timestampEpoch = now - 150_000L,
                isPinned = false,
                likesCount = 178,
                isLikedByMe = false,
                referenceNumber = "INP-NEWS-42"
            )
        )
        dao.insertStatements(statements)
    }
}
