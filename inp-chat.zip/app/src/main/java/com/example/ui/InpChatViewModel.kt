package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ChatCategory
import com.example.data.ChatRoomEntity
import com.example.data.InpDatabase
import com.example.data.InpRepository
import com.example.data.MessageEntity
import com.example.data.MessageType
import com.example.data.OfficialStatementEntity
import com.example.data.SocialPlatform
import com.example.data.UserProfile
import com.example.util.VoiceAudioHelper
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Locale

enum class AppRootScreen {
    SPLASH,
    SOCIAL_AUTH,
    MAIN_HOME
}

enum class MainWhatsAppTab(val titleAr: String) {
    CHATS("المحادثات"),
    UPDATES("البيانات والتعاميم"),
    SETTINGS("الإعدادات")
}

data class ActiveCallState(
    val room: ChatRoomEntity,
    val isVideoCall: Boolean,
    val isMuted: Boolean = false,
    val isSpeakerOn: Boolean = true,
    val isCameraEnabled: Boolean = true,
    val durationSeconds: Int = 0,
    val callStatusText: String = "جاري الاتصال الآمن عبر INP..."
)

@OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
class InpChatViewModel(application: Application) : AndroidViewModel(application) {

    private val database = InpDatabase.getInstance(application)
    private val repository = InpRepository(application, database.inpDao())
    private val voiceAudioHelper = VoiceAudioHelper(application)

    val userProfile: StateFlow<UserProfile> = repository.userProfile

    val chatRooms: StateFlow<List<ChatRoomEntity>> = repository.chatRooms
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val officialStatements: StateFlow<List<OfficialStatementEntity>> = repository.officialStatements
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _rootScreen = MutableStateFlow(AppRootScreen.SPLASH)
    val rootScreen: StateFlow<AppRootScreen> = _rootScreen.asStateFlow()

    private val _selectedTab = MutableStateFlow(MainWhatsAppTab.CHATS)
    val selectedTab: StateFlow<MainWhatsAppTab> = _selectedTab.asStateFlow()

    private val _selectedChatRoomId = MutableStateFlow<Long?>(null)
    val selectedChatRoomId: StateFlow<Long?> = _selectedChatRoomId.asStateFlow()

    val currentRoomMessages: StateFlow<List<MessageEntity>> = _selectedChatRoomId
        .flatMapLatest { roomId ->
            if (roomId == null) flowOf(emptyList())
            else repository.observeMessages(roomId)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _isSearchBarVisible = MutableStateFlow(false)
    val isSearchBarVisible: StateFlow<Boolean> = _isSearchBarVisible.asStateFlow()

    private val _selectedChatFilter = MutableStateFlow("ALL")
    val selectedChatFilter: StateFlow<String> = _selectedChatFilter.asStateFlow()

    private val _selectedStatementFilter = MutableStateFlow("الكل")
    val selectedStatementFilter: StateFlow<String> = _selectedStatementFilter.asStateFlow()

    private val _activeCallState = MutableStateFlow<ActiveCallState?>(null)
    val activeCallState: StateFlow<ActiveCallState?> = _activeCallState.asStateFlow()

    private val _isRecordingVoice = MutableStateFlow(false)
    val isRecordingVoice: StateFlow<Boolean> = _isRecordingVoice.asStateFlow()

    private val _recordingSeconds = MutableStateFlow(0)
    val recordingSeconds: StateFlow<Int> = _recordingSeconds.asStateFlow()

    private val _playingMessageId = MutableStateFlow<Long?>(null)
    val playingMessageId: StateFlow<Long?> = _playingMessageId.asStateFlow()

    private val _playbackProgress = MutableStateFlow(0f)
    val playbackProgress: StateFlow<Float> = _playbackProgress.asStateFlow()

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    private var callTimerJob: Job? = null
    private var voiceRecordJob: Job? = null
    private var voicePlaybackJob: Job? = null
    private var activeRecordingPath: String = ""

    init {
        viewModelScope.launch {
            repository.ensureSeeded()
        }
    }

    fun onSplashFinished() {
        if (_rootScreen.value == AppRootScreen.SPLASH) {
            _rootScreen.value = if (userProfile.value.isRegistered) {
                AppRootScreen.MAIN_HOME
            } else {
                AppRootScreen.SOCIAL_AUTH
            }
        }
    }

    fun completeSocialRegistration(
        fullName: String,
        socialPlatform: SocialPlatform,
        socialHandle: String,
        roleTitle: String,
        governorate: String,
        enableLeadership: Boolean
    ) {
        val current = userProfile.value
        repository.updateUserProfile(
            current.copy(
                fullName = fullName.ifBlank { "عضو الهوية القومية" },
                socialPlatform = socialPlatform,
                socialHandle = socialHandle.ifBlank { "@inp.iraq" },
                roleTitle = roleTitle.ifBlank { "عضو عامل - INP" },
                governorate = governorate.ifBlank { "بغداد" },
                isLeadershipMode = enableLeadership,
                isRegistered = true
            )
        )
        _rootScreen.value = AppRootScreen.MAIN_HOME
        showBanner("مرحباً بك في منصة INP Chat • العراق أولاً")
    }

    fun openSocialAuthEditor() {
        _rootScreen.value = AppRootScreen.SOCIAL_AUTH
    }

    fun updateProfileSettings(updated: UserProfile, bannerMessage: String? = null) {
        repository.updateUserProfile(updated)
        if (!bannerMessage.isNullOrBlank()) {
            showBanner(bannerMessage)
        }
    }

    fun selectTab(tab: MainWhatsAppTab) {
        _selectedTab.value = tab
    }

    fun toggleSearchBar() {
        val next = !_isSearchBarVisible.value
        _isSearchBarVisible.value = next
        if (!next) {
            _searchQuery.value = ""
        }
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setChatFilter(filter: String) {
        _selectedChatFilter.value = filter
    }

    fun setStatementFilter(filter: String) {
        _selectedStatementFilter.value = filter
    }

    fun openChatRoom(room: ChatRoomEntity) {
        _selectedChatRoomId.value = room.id
        viewModelScope.launch {
            repository.markRoomRead(room.id)
        }
    }

    fun closeChatRoom() {
        stopVoicePlayback()
        cancelVoiceRecording()
        _selectedChatRoomId.value = null
    }

    fun togglePinRoom(room: ChatRoomEntity) {
        viewModelScope.launch {
            repository.togglePinRoom(room)
            showBanner(if (room.isPinned) "تم إلغاء تثبيت المحادثة" else "تم تثبيت المحادثة في الأعلى")
        }
    }

    fun toggleMuteRoom(room: ChatRoomEntity) {
        viewModelScope.launch {
            repository.toggleMuteRoom(room)
            showBanner(if (room.isMuted) "تم تفعيل إشعارات المحادثة" else "تم كتم إشعارات المحادثة")
        }
    }

    fun createNewRoom(
        title: String,
        subtitle: String,
        category: ChatCategory,
        socialHandle: String,
        socialPlatform: SocialPlatform,
        membersCount: Int
    ) {
        viewModelScope.launch {
            val newId = repository.createNewChatRoom(
                title = title,
                subtitle = subtitle,
                category = category,
                socialHandle = socialHandle,
                socialPlatform = socialPlatform,
                membersCount = membersCount
            )
            _selectedChatRoomId.value = newId
            showBanner("تم إنشاء \"$title\" بنجاح")
        }
    }

    fun sendTextOrLinkMessage(room: ChatRoomEntity, rawText: String) {
        val trimmed = rawText.trim()
        if (trimmed.isEmpty()) return
        val urlRegex = "(https?://[\\w\\-._~:/?#\\[\\]@!$&'()*+,;=%]+)".toRegex()
        val foundUrl = urlRegex.find(trimmed)?.value

        viewModelScope.launch {
            if (foundUrl != null) {
                val hostTitle = when {
                    foundUrl.contains("tiktok.com", ignoreCase = true) -> "رابط TikTok رسمي • INP"
                    foundUrl.contains("instagram.com", ignoreCase = true) -> "رابط Instagram رسمي • INP"
                    else -> "رابط خارجي مرفق • INP Chat"
                }
                repository.sendMessage(
                    room = room,
                    content = trimmed,
                    type = MessageType.LINK,
                    linkUrl = foundUrl,
                    linkTitle = hostTitle
                )
            } else {
                repository.sendMessage(
                    room = room,
                    content = trimmed,
                    type = MessageType.TEXT
                )
            }
            delay(1100)
            repository.generateCadreAutoReply(room, MessageType.TEXT)
        }
    }

    fun sendRichLinkMessage(room: ChatRoomEntity, url: String, title: String, comment: String) {
        val normalizedUrl = if (url.startsWith("http")) url else "https://$url"
        viewModelScope.launch {
            repository.sendMessage(
                room = room,
                content = comment.ifBlank { title.ifBlank { normalizedUrl } },
                type = MessageType.LINK,
                linkUrl = normalizedUrl,
                linkTitle = title.ifBlank { "رابط مشارك عبر INP Chat" }
            )
            delay(1100)
            repository.generateCadreAutoReply(room, MessageType.LINK)
        }
    }

    fun sendMediaMessage(
        room: ChatRoomEntity,
        caption: String,
        mediaUri: String,
        isVideo: Boolean
    ) {
        viewModelScope.launch {
            repository.sendMessage(
                room = room,
                content = caption.ifBlank {
                    if (isVideo) "مقطع فيديو من الفعاليات الوطنية - INP"
                    else "صورة مرفقة - حزب الهوية القومية العراقية"
                },
                type = if (isVideo) MessageType.VIDEO else MessageType.IMAGE,
                mediaUri = mediaUri,
                voiceDurationSec = if (isVideo) 45 else 0
            )
            delay(1200)
            repository.generateCadreAutoReply(
                room,
                if (isVideo) MessageType.VIDEO else MessageType.IMAGE
            )
        }
    }

    fun startVoiceRecording() {
        if (_isRecordingVoice.value) return
        activeRecordingPath = voiceAudioHelper.startRecording()
        _isRecordingVoice.value = true
        _recordingSeconds.value = 0
        voiceRecordJob?.cancel()
        voiceRecordJob = viewModelScope.launch {
            while (_isRecordingVoice.value) {
                delay(1000)
                _recordingSeconds.value += 1
            }
        }
    }

    fun cancelVoiceRecording() {
        voiceRecordJob?.cancel()
        if (_isRecordingVoice.value) {
            voiceAudioHelper.stopRecording()
        }
        _isRecordingVoice.value = false
        _recordingSeconds.value = 0
    }

    fun finishAndSendVoiceRecording(room: ChatRoomEntity) {
        if (!_isRecordingVoice.value) return
        voiceRecordJob?.cancel()
        val duration = _recordingSeconds.value.coerceAtLeast(2)
        val savedPath = voiceAudioHelper.stopRecording()
        _isRecordingVoice.value = false
        _recordingSeconds.value = 0

        viewModelScope.launch {
            repository.sendMessage(
                room = room,
                content = "رسالة صوتية مسجلة (${formatSeconds(duration)})",
                type = MessageType.VOICE,
                mediaUri = savedPath,
                voiceDurationSec = duration
            )
            delay(1200)
            repository.generateCadreAutoReply(room, MessageType.VOICE)
        }
    }

    fun toggleVoiceNotePlayback(message: MessageEntity) {
        if (_playingMessageId.value == message.id) {
            stopVoicePlayback()
            return
        }
        stopVoicePlayback()
        _playingMessageId.value = message.id
        _playbackProgress.value = 0f

        val totalSec = message.voiceDurationSec.coerceAtLeast(3)
        voiceAudioHelper.playAudioIfRealFile(message.mediaUri) {
            stopVoicePlayback()
        }

        voicePlaybackJob = viewModelScope.launch {
            val steps = totalSec * 10
            for (step in 1..steps) {
                delay(100)
                _playbackProgress.value = step.toFloat() / steps.toFloat()
            }
            stopVoicePlayback()
        }
    }

    fun stopVoicePlayback() {
        voicePlaybackJob?.cancel()
        voiceAudioHelper.stopPlayback()
        _playingMessageId.value = null
        _playbackProgress.value = 0f
    }

    fun toggleMessageReaction(message: MessageEntity, emoji: String) {
        viewModelScope.launch {
            repository.toggleMessageReaction(message, emoji)
        }
    }

    fun startCall(room: ChatRoomEntity, isVideoCall: Boolean) {
        callTimerJob?.cancel()
        _activeCallState.value = ActiveCallState(
            room = room,
            isVideoCall = isVideoCall,
            durationSeconds = 0,
            callStatusText = "جاري الاتصال المشفر..."
        )
        callTimerJob = viewModelScope.launch {
            delay(1200)
            _activeCallState.value = _activeCallState.value?.copy(
                callStatusText = "متصل الآن • تشفير INP تام"
            )
            while (_activeCallState.value != null) {
                delay(1000)
                val current = _activeCallState.value ?: break
                _activeCallState.value = current.copy(
                    durationSeconds = current.durationSeconds + 1
                )
            }
        }
    }

    fun toggleCallMute() {
        val current = _activeCallState.value ?: return
        _activeCallState.value = current.copy(isMuted = !current.isMuted)
    }

    fun toggleCallSpeaker() {
        val current = _activeCallState.value ?: return
        _activeCallState.value = current.copy(isSpeakerOn = !current.isSpeakerOn)
    }

    fun toggleCallCamera() {
        val current = _activeCallState.value ?: return
        _activeCallState.value = current.copy(isCameraEnabled = !current.isCameraEnabled)
    }

    fun endActiveCall() {
        val current = _activeCallState.value ?: return
        callTimerJob?.cancel()
        _activeCallState.value = null
        val callKind = if (current.isVideoCall) "مكالمة مرئية صادرة" else "مكالمة صوتية صادرة"
        val formattedDuration = formatSeconds(current.durationSeconds.coerceAtLeast(1))
        viewModelScope.launch {
            repository.sendMessage(
                room = current.room,
                content = "$callKind • المدة $formattedDuration",
                type = MessageType.CALL_LOG
            )
            showBanner("انتهت المكالمة ($formattedDuration)")
        }
    }

    fun publishOfficialStatement(
        title: String,
        category: String,
        content: String,
        isPinned: Boolean,
        referenceNumber: String
    ) {
        viewModelScope.launch {
            repository.publishOfficialStatement(
                title = title,
                category = category,
                content = content,
                isPinned = isPinned,
                referenceNumber = referenceNumber
            )
            showBanner("تم نشر «$title» في تبويب البيانات والتعاميم")
        }
    }

    fun toggleStatementLike(statement: OfficialStatementEntity) {
        viewModelScope.launch {
            repository.toggleStatementLike(statement)
        }
    }

    fun toggleStatementPin(statement: OfficialStatementEntity) {
        viewModelScope.launch {
            repository.toggleStatementPin(statement)
            showBanner(if (statement.isPinned) "تم إلغاء تثبيت البيان" else "تم تثبيت البيان في أعلى القائمة")
        }
    }

    fun deleteStatement(statement: OfficialStatementEntity) {
        viewModelScope.launch {
            repository.deleteStatement(statement.id)
            showBanner("تم حذف البيان من القائمة")
        }
    }

    fun shareStatementToRoom(statement: OfficialStatementEntity, room: ChatRoomEntity) {
        viewModelScope.launch {
            repository.sendMessage(
                room = room,
                content = "${statement.title}\n\n${statement.content.take(220)}...",
                type = MessageType.OFFICIAL_SHARE,
                linkTitle = "${statement.category} • ${statement.referenceNumber}"
            )
            _selectedTab.value = MainWhatsAppTab.CHATS
            _selectedChatRoomId.value = room.id
            showBanner("تمت مشاركة البيان الرسمي إلى «${room.title}»")
        }
    }

    fun resetDemoData() {
        viewModelScope.launch {
            repository.resetAndReseedAll()
            showBanner("تمت استعادة البيانات الافتراضية للحزب بنجاح")
        }
    }

    fun showBanner(message: String) {
        _statusBanner.value = message
        viewModelScope.launch {
            delay(3200)
            if (_statusBanner.value == message) {
                _statusBanner.value = null
            }
        }
    }

    private fun formatSeconds(seconds: Int): String {
        val m = seconds / 60
        val s = seconds % 60
        return String.format(Locale.US, "%02d:%02d", m, s)
    }

    override fun onCleared() {
        super.onCleared()
        stopVoicePlayback()
        cancelVoiceRecording()
    }
}
