package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import com.example.R
import com.example.data.ChatRoomEntity
import com.example.data.MessageEntity
import com.example.data.MessageType
import com.example.data.SocialPlatform
import com.example.data.UserProfile
import com.example.ui.theme.ClassicChatWallpaper
import com.example.ui.theme.IncomingBubbleWhite
import com.example.ui.theme.InpCrimsonRed
import com.example.ui.theme.InpPatrioticBlue
import com.example.ui.theme.InstagramMagenta
import com.example.ui.theme.OutgoingBubbleClassic
import com.example.ui.theme.TikTokBlack
import com.example.ui.theme.WhatsAppBrightGreen
import com.example.ui.theme.WhatsAppDarkGreen
import com.example.ui.theme.WhatsAppTealGreen
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatDetailScreen(
    room: ChatRoomEntity,
    messages: List<MessageEntity>,
    userProfile: UserProfile,
    isRecordingVoice: Boolean,
    recordingSeconds: Int,
    playingMessageId: Long?,
    playbackProgress: Float,
    onBack: () -> Unit,
    onSendTextOrLink: (String) -> Unit,
    onSendRichLink: (url: String, title: String, comment: String) -> Unit,
    onSendMedia: (caption: String, mediaUri: String, isVideo: Boolean) -> Unit,
    onStartVoiceRecording: () -> Unit,
    onCancelVoiceRecording: () -> Unit,
    onFinishVoiceRecording: () -> Unit,
    onToggleVoicePlayback: (MessageEntity) -> Unit,
    onToggleReaction: (MessageEntity, String) -> Unit,
    onStartVoiceCall: () -> Unit,
    onStartVideoCall: () -> Unit,
    onTogglePinRoom: () -> Unit,
    onToggleMuteRoom: () -> Unit
) {
    BackHandler(onBack = onBack)

    val context = LocalContext.current
    val listState = rememberLazyListState()

    var messageInput by remember { mutableStateOf("") }
    var showAttachmentSheet by remember { mutableStateOf(false) }
    var showLinkDialog by remember { mutableStateOf(false) }
    var showHeaderMenu by remember { mutableStateOf(false) }
    var previewMediaMessage by remember { mutableStateOf<MessageEntity?>(null) }

    // Zero-permission Android Photo Picker for Images
    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            onSendMedia(
                "صورة مرفقة من المعرض • ${userProfile.socialHandle}",
                uri.toString(),
                false
            )
        }
    }

    // Zero-permission Android Photo Picker for Videos
    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            onSendMedia(
                "مقطع فيديو مرفق من المعرض • ${userProfile.socialHandle}",
                uri.toString(),
                true
            )
        }
    }

    // Runtime RECORD_AUDIO Permission Launcher for Voice Notes
    val audioPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ ->
        // Start recording whether physical mic permission was granted or fallback waveform is used
        onStartVoiceRecording()
    }

    val wallpaperColor = remember(userProfile.chatWallpaperHex) {
        try {
            Color(android.graphics.Color.parseColor(userProfile.chatWallpaperHex))
        } catch (_: Exception) {
            ClassicChatWallpaper
        }
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(wallpaperColor)
            .imePadding()
            .testTag("chat_detail_screen")
    ) {
        // 1. Classic WhatsApp Green Chat Header
        Surface(
            color = WhatsAppDarkGreen,
            shadowElevation = 4.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.statusBars)
                    .padding(horizontal = 6.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.testTag("chat_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "رجوع",
                        tint = Color.White
                    )
                }

                Image(
                    painter = painterResource(id = R.drawable.img_inp_party_logo),
                    contentDescription = room.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .border(1.dp, Color.White.copy(alpha = 0.5f), CircleShape)
                )

                Spacer(modifier = Modifier.width(10.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = room.title,
                        color = Color.White,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${room.socialLinkHandle} • ${room.membersCount} عضو متصل",
                        color = Color.White.copy(alpha = 0.84f),
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // Voice Call & Video Call Header Actions
                IconButton(
                    onClick = onStartVideoCall,
                    modifier = Modifier.testTag("header_video_call_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Videocam,
                        contentDescription = "مكالمة مرئية",
                        tint = Color.White
                    )
                }

                IconButton(
                    onClick = onStartVoiceCall,
                    modifier = Modifier.testTag("header_voice_call_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Call,
                        contentDescription = "مكالمة صوتية",
                        tint = Color.White
                    )
                }

                Box {
                    IconButton(onClick = { showHeaderMenu = true }) {
                        Icon(
                            imageVector = Icons.Default.MoreVert,
                            contentDescription = "خيارات المحادثة",
                            tint = Color.White
                        )
                    }
                    DropdownMenu(
                        expanded = showHeaderMenu,
                        onDismissRequest = { showHeaderMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text(if (room.isPinned) "إلغاء تثبيت المحادثة" else "تثبيت المحادثة") },
                            onClick = {
                                showHeaderMenu = false
                                onTogglePinRoom()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text(if (room.isMuted) "تفعيل الإشعارات" else "كتم الإشعارات") },
                            onClick = {
                                showHeaderMenu = false
                                onToggleMuteRoom()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("مشاركة رابط TikTok / Instagram") },
                            onClick = {
                                showHeaderMenu = false
                                showLinkDialog = true
                            }
                        )
                    }
                }
            }
        }

        // 2. Messages List on Calm Classic Wallpaper
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 10.dp),
            contentPadding = PaddingValues(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Encryption Notice Banner at Top of Chat
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Surface(
                        color = Color(0xFFFFF8E1),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(0.8.dp, Color(0xFFFFE082))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = null,
                                tint = Color(0xFF795548),
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "الرسائل والمكالمات الصوتية والمرئية مشفرة بالكامل بين أعضاء حزب الهوية القومية العراقية (INP)",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFF5D4037)
                            )
                        }
                    }
                }
            }

            items(messages, key = { it.id }) { msg ->
                ChatMessageBubble(
                    message = msg,
                    readReceiptsEnabled = userProfile.readReceiptsEnabled,
                    isPlayingVoice = playingMessageId == msg.id,
                    playbackProgress = if (playingMessageId == msg.id) playbackProgress else 0f,
                    onToggleVoicePlay = { onToggleVoicePlayback(msg) },
                    onToggleReaction = { emoji -> onToggleReaction(msg, emoji) },
                    onOpenMediaPreview = { previewMediaMessage = msg },
                    onCallBack = {
                        if (msg.content.contains("مرئية")) onStartVideoCall()
                        else onStartVoiceCall()
                    }
                )
            }
        }

        // 3. Bottom Input Bar with Attachment Button, Voice Recorder, and INP Branded Send Button
        Surface(
            color = Color(0xFFF0F2F5),
            shadowElevation = 6.dp,
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
        ) {
            if (isRecordingVoice) {
                // Active Voice Note Recording Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .clip(CircleShape)
                                .background(InpCrimsonRed)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = String.format(
                                Locale.US,
                                "جاري تسجيل رسالة صوتية... %02d:%02d",
                                recordingSeconds / 60,
                                recordingSeconds % 60
                            ),
                            style = MaterialTheme.typography.titleSmall,
                            color = InpCrimsonRed
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onCancelVoiceRecording) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "إلغاء التسجيل",
                                tint = Color(0xFF667781)
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        InpBrandedSendButton(
                            onClick = onFinishVoiceRecording,
                            testTag = "send_voice_note_button"
                        )
                    }
                }
            } else {
                // Standard Message Input Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Attachment (+) Button
                    IconButton(
                        onClick = { showAttachmentSheet = true },
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(Color.White)
                            .testTag("attachment_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AttachFile,
                            contentDescription = "إرفاق ملفات وصور وروابط",
                            tint = WhatsAppDarkGreen
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    // Message Text Field Pill
                    Surface(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(24.dp),
                        color = Color.White,
                        border = BorderStroke(1.dp, Color(0xFFDADEE2))
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 6.dp)
                        ) {
                            TextField(
                                value = messageInput,
                                onValueChange = { messageInput = it },
                                placeholder = {
                                    Text(
                                        text = "اكتب رسالة أو الصق رابط...",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = Color(0xFF8696A0)
                                    )
                                },
                                colors = TextFieldDefaults.colors(
                                    focusedContainerColor = Color.Transparent,
                                    unfocusedContainerColor = Color.Transparent,
                                    focusedIndicatorColor = Color.Transparent,
                                    unfocusedIndicatorColor = Color.Transparent
                                ),
                                maxLines = 4,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("chat_message_input")
                            )

                            // Quick Voice Record Mic Button inside Pill
                            IconButton(
                                onClick = {
                                    val hasAudioPerm = ContextCompat.checkSelfPermission(
                                        context,
                                        Manifest.permission.RECORD_AUDIO
                                    ) == PackageManager.PERMISSION_GRANTED
                                    if (hasAudioPerm) {
                                        onStartVoiceRecording()
                                    } else {
                                        audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                    }
                                },
                                modifier = Modifier.testTag("voice_record_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Mic,
                                    contentDescription = "تسجيل رسالة صوتية",
                                    tint = WhatsAppTealGreen
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Custom Send Button Featuring Bold "INP" Letters & Mini Circle Emblem
                    InpBrandedSendButton(
                        onClick = {
                            if (messageInput.isNotBlank()) {
                                onSendTextOrLink(messageInput)
                                messageInput = ""
                            } else {
                                // If text is empty, tapping INP button starts voice note or sends quick party greeting
                                onSendTextOrLink("تحية وطنية من ${userProfile.fullName} (${userProfile.socialHandle}) • العراق أولاً 🇮🇶")
                            }
                        },
                        testTag = "inp_send_button"
                    )
                }
            }
        }
    }

    // Attachment Options Modal Bottom Sheet
    if (showAttachmentSheet) {
        ModalBottomSheet(
            onDismissRequest = { showAttachmentSheet = false },
            containerColor = Color.White
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp)
                    .navigationBarsPadding()
            ) {
                Text(
                    text = "إرفاق وسائط ومحتوى في المحادثة",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold
                    ),
                    color = WhatsAppDarkGreen
                )
                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    AttachmentOptionItem(
                        icon = Icons.Default.Image,
                        label = "صورة من المعرض",
                        bgColor = Color(0xFF8E24AA),
                        onClick = {
                            showAttachmentSheet = false
                            imagePickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        }
                    )
                    AttachmentOptionItem(
                        icon = Icons.Default.Videocam,
                        label = "فيديو من المعرض",
                        bgColor = Color(0xFFE53935),
                        onClick = {
                            showAttachmentSheet = false
                            videoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                            )
                        }
                    )
                    AttachmentOptionItem(
                        icon = Icons.Default.Link,
                        label = "إرسال رابط",
                        bgColor = InpPatrioticBlue,
                        onClick = {
                            showAttachmentSheet = false
                            showLinkDialog = true
                        }
                    )
                    AttachmentOptionItem(
                        icon = Icons.Default.Mic,
                        label = "رسالة صوتية",
                        bgColor = WhatsAppTealGreen,
                        onClick = {
                            showAttachmentSheet = false
                            val hasAudioPerm = ContextCompat.checkSelfPermission(
                                context,
                                Manifest.permission.RECORD_AUDIO
                            ) == PackageManager.PERMISSION_GRANTED
                            if (hasAudioPerm) {
                                onStartVoiceRecording()
                            } else {
                                audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        }
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Quick Party Media Templates (instant 1-tap photo/video sharing)
                Text(
                    text = "أو مشاركة سريعة من أرشيف الحزب الإعلامي:",
                    style = MaterialTheme.typography.labelMedium,
                    color = Color(0xFF54656F)
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            showAttachmentSheet = false
                            onSendMedia(
                                "الهوية الرسمية لحزب الهوية القومية العراقية - العراق أولاً",
                                "party_banner_meeting",
                                false
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = InpCrimsonRed),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Image,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("إرسال بوستر الحزب")
                    }

                    Button(
                        onClick = {
                            showAttachmentSheet = false
                            onSendMedia(
                                "فيديو الحملة الوطنية لحزب الهوية القومية العراقية (INP)",
                                "party_promo_video",
                                true
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = WhatsAppDarkGreen),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Videocam,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("إرسال فيديو وطني")
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }

    // Share Rich Link Dialog
    if (showLinkDialog) {
        var linkUrl by remember { mutableStateOf("https://www.tiktok.com/${userProfile.socialHandle}") }
        var linkTitle by remember { mutableStateOf("بث مباشر ومنشور رسمي • ${userProfile.socialHandle}") }
        var linkComment by remember { mutableStateOf("يرجى من جميع الكوادر التفاعل والمشاركة") }

        AlertDialog(
            onDismissRequest = { showLinkDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Link,
                        contentDescription = null,
                        tint = InpPatrioticBlue
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("إرسال رابط (TikTok / Instagram / ويب)")
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = linkUrl,
                        onValueChange = { linkUrl = it },
                        label = { Text("عنوان الرابط (URL)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = linkTitle,
                        onValueChange = { linkTitle = it },
                        label = { Text("عنوان المعاينة") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = linkComment,
                        onValueChange = { linkComment = it },
                        label = { Text("رسالة مرفقة مع الرابط") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (linkUrl.isNotBlank()) {
                            onSendRichLink(linkUrl.trim(), linkTitle.trim(), linkComment.trim())
                            showLinkDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = WhatsAppDarkGreen)
                ) {
                    Text("إرسال الرابط")
                }
            },
            dismissButton = {
                TextButton(onClick = { showLinkDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // Fullscreen Media Preview Dialog
    previewMediaMessage?.let { mediaMsg ->
        AlertDialog(
            onDismissRequest = { previewMediaMessage = null },
            title = {
                Text(
                    text = if (mediaMsg.messageType == MessageType.VIDEO.name)
                        "مشغل الفيديو • INP Chat"
                    else
                        "معاينة الصورة • INP Chat",
                    style = MaterialTheme.typography.titleMedium
                )
            },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(240.dp),
                        shape = RoundedCornerShape(16.dp),
                        color = Color.Black
                    ) {
                        if (mediaMsg.mediaUri.startsWith("content://") || mediaMsg.mediaUri.startsWith("file://")) {
                            AsyncImage(
                                model = Uri.parse(mediaMsg.mediaUri),
                                contentDescription = mediaMsg.content,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            Image(
                                painter = painterResource(id = R.drawable.img_inp_party_logo),
                                contentDescription = mediaMsg.content,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = mediaMsg.content,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { previewMediaMessage = null }) {
                    Text("إغلاق")
                }
            }
        )
    }
}

@Composable
private fun InpBrandedSendButton(
    onClick: () -> Unit,
    testTag: String
) {
    Surface(
        modifier = Modifier
            .size(50.dp)
            .clip(CircleShape)
            .clickable(onClick = onClick)
            .testTag(testTag),
        shape = CircleShape,
        color = Color(0xFF1E9E3E),
        shadowElevation = 4.dp,
        border = BorderStroke(2.dp, Color.White)
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .fillMaxSize()
                .padding(4.dp)
                .border(1.5.dp, Color.White.copy(alpha = 0.9f), CircleShape)
        ) {
            Text(
                text = "INP",
                color = Color.White,
                style = MaterialTheme.typography.labelLarge.copy(
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 13.sp,
                    letterSpacing = 0.5.sp
                )
            )
        }
    }
}

@Composable
private fun ChatMessageBubble(
    message: MessageEntity,
    readReceiptsEnabled: Boolean,
    isPlayingVoice: Boolean,
    playbackProgress: Float,
    onToggleVoicePlay: () -> Unit,
    onToggleReaction: (String) -> Unit,
    onOpenMediaPreview: () -> Unit,
    onCallBack: () -> Unit
) {
    val context = LocalContext.current
    val isOutgoing = message.isOutgoing
    val bubbleColor = if (isOutgoing) OutgoingBubbleClassic else IncomingBubbleWhite
    val bubbleShape = if (isOutgoing) {
        RoundedCornerShape(topStart = 16.dp, topEnd = 4.dp, bottomStart = 16.dp, bottomEnd = 16.dp)
    } else {
        RoundedCornerShape(topStart = 4.dp, topEnd = 16.dp, bottomStart = 16.dp, bottomEnd = 16.dp)
    }

    var showReactionsBar by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isOutgoing) Alignment.Start else Alignment.End
    ) {
        Surface(
            modifier = Modifier
                .widthIn(min = 120.dp, max = 325.dp)
                .clickable { showReactionsBar = !showReactionsBar },
            shape = bubbleShape,
            color = bubbleColor,
            shadowElevation = 1.2.dp
        ) {
            Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                // Incoming Sender Name + Social Handle Badge
                if (!isOutgoing) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = message.senderName,
                            style = MaterialTheme.typography.labelLarge.copy(
                                fontWeight = FontWeight.Bold
                            ),
                            color = InpCrimsonRed
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            color = if (message.senderPlatform == SocialPlatform.TIKTOK.name)
                                TikTokBlack.copy(alpha = 0.08f)
                            else
                                InstagramMagenta.copy(alpha = 0.1f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = message.senderSocialHandle,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (message.senderPlatform == SocialPlatform.TIKTOK.name)
                                    TikTokBlack else InstagramMagenta,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                }

                // Message Body by Type
                when (message.messageType) {
                    MessageType.VOICE.name -> {
                        VoiceMessageContent(
                            durationSec = message.voiceDurationSec,
                            waveformSeed = message.waveformSeed,
                            isPlaying = isPlayingVoice,
                            progress = playbackProgress,
                            onTogglePlay = onToggleVoicePlay
                        )
                    }

                    MessageType.IMAGE.name -> {
                        ImageMessageContent(
                            message = message,
                            onClick = onOpenMediaPreview
                        )
                    }

                    MessageType.VIDEO.name -> {
                        VideoMessageContent(
                            message = message,
                            onClick = onOpenMediaPreview
                        )
                    }

                    MessageType.LINK.name -> {
                        LinkMessageContent(
                            message = message,
                            onOpenUrl = { url ->
                                try {
                                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                                } catch (_: Exception) {
                                }
                            }
                        )
                    }

                    MessageType.CALL_LOG.name -> {
                        CallLogMessageContent(
                            message = message,
                            onCallBack = onCallBack
                        )
                    }

                    MessageType.OFFICIAL_SHARE.name -> {
                        OfficialShareMessageContent(message = message)
                    }

                    else -> {
                        Text(
                            text = message.content,
                            style = MaterialTheme.typography.bodyLarge,
                            color = Color(0xFF111B21)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Timestamp + Outgoing Read Receipt + Reaction Pill
                Row(
                    modifier = Modifier.align(Alignment.End),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (message.reactionEmoji.isNotBlank()) {
                        Surface(
                            color = Color.White,
                            shape = RoundedCornerShape(50),
                            border = BorderStroke(0.5.dp, Color(0xFFDADEE2)),
                            modifier = Modifier.padding(end = 6.dp)
                        ) {
                            Text(
                                text = message.reactionEmoji,
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp)
                            )
                        }
                    }

                    Text(
                        text = message.timestampText,
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                        color = Color(0xFF667781)
                    )

                    if (isOutgoing) {
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.Default.DoneAll,
                            contentDescription = "تمت القراءة",
                            tint = if (readReceiptsEnabled) InpPatrioticBlue else Color(0xFF8696A0),
                            modifier = Modifier.size(15.dp)
                        )
                    }
                }
            }
        }

        // Quick Reaction Bar when message is tapped
        AnimatedVisibility(visible = showReactionsBar) {
            Surface(
                color = Color.White,
                shape = RoundedCornerShape(50),
                shadowElevation = 3.dp,
                modifier = Modifier.padding(top = 4.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    listOf("🇮🇶", "👍", "❤️", "🔥", "👏", "✅").forEach { emoji ->
                        Text(
                            text = emoji,
                            fontSize = 16.sp,
                            modifier = Modifier.clickable {
                                onToggleReaction(emoji)
                                showReactionsBar = false
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun VoiceMessageContent(
    durationSec: Int,
    waveformSeed: Int,
    isPlaying: Boolean,
    progress: Float,
    onTogglePlay: () -> Unit
) {
    val bars = remember(waveformSeed) {
        List(24) { idx ->
            val v = ((idx * 17 + waveformSeed * 13) % 100) / 100f
            0.25f + (v * 0.75f)
        }
    }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        IconButton(
            onClick = onTogglePlay,
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(WhatsAppTealGreen)
        ) {
            Icon(
                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                contentDescription = if (isPlaying) "إيقاف مؤقت" else "تشغيل الرسالة الصوتية",
                tint = Color.White
            )
        }

        Spacer(modifier = Modifier.width(10.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(26.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                bars.forEachIndexed { index, heightRatio ->
                    val barFraction = index.toFloat() / bars.size.toFloat()
                    val isPlayed = isPlaying && barFraction <= progress
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height((24.dp * heightRatio).coerceAtLeast(5.dp))
                            .clip(RoundedCornerShape(50))
                            .background(
                                if (isPlayed) WhatsAppDarkGreen
                                else WhatsAppTealGreen.copy(alpha = 0.42f)
                            )
                    )
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = String.format(
                    Locale.US,
                    "رسالة صوتية • %02d:%02d",
                    durationSec / 60,
                    durationSec % 60
                ),
                style = MaterialTheme.typography.labelSmall,
                color = Color(0xFF54656F)
            )
        }
    }
}

@Composable
private fun ImageMessageContent(
    message: MessageEntity,
    onClick: () -> Unit
) {
    Column(modifier = Modifier.clickable(onClick = onClick)) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .height(175.dp),
            shape = RoundedCornerShape(12.dp),
            color = Color(0xFFE0E0E0)
        ) {
            if (message.mediaUri.startsWith("content://") || message.mediaUri.startsWith("file://")) {
                AsyncImage(
                    model = Uri.parse(message.mediaUri),
                    contentDescription = message.content,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Image(
                    painter = painterResource(id = R.drawable.img_inp_party_logo),
                    contentDescription = message.content,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
        if (message.content.isNotBlank()) {
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = message.content,
                style = MaterialTheme.typography.bodyMedium,
                color = Color(0xFF111B21)
            )
        }
    }
}

@Composable
private fun VideoMessageContent(
    message: MessageEntity,
    onClick: () -> Unit
) {
    Column(modifier = Modifier.clickable(onClick = onClick)) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(175.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color.Black),
            contentAlignment = Alignment.Center
        ) {
            if (message.mediaUri.startsWith("content://") || message.mediaUri.startsWith("file://")) {
                AsyncImage(
                    model = Uri.parse(message.mediaUri),
                    contentDescription = message.content,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Image(
                    painter = painterResource(id = R.drawable.img_inp_party_logo),
                    contentDescription = message.content,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.32f))
            )
            Surface(
                shape = CircleShape,
                color = WhatsAppBrightGreen,
                modifier = Modifier.size(50.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "تشغيل الفيديو",
                        tint = Color.White,
                        modifier = Modifier.size(30.dp)
                    )
                }
            }
            Surface(
                color = Color.Black.copy(alpha = 0.65f),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(8.dp)
            ) {
                Text(
                    text = "🎬 فيديو HD",
                    color = Color.White,
                    style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                )
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = message.content,
            style = MaterialTheme.typography.bodyMedium,
            color = Color(0xFF111B21)
        )
    }
}

@Composable
private fun LinkMessageContent(
    message: MessageEntity,
    onOpenUrl: (String) -> Unit
) {
    Column {
        Surface(
            color = Color.Black.copy(alpha = 0.05f),
            shape = RoundedCornerShape(10.dp),
            border = BorderStroke(1.dp, InpPatrioticBlue.copy(alpha = 0.3f)),
            modifier = Modifier
                .fillMaxWidth()
                .clickable {
                    if (message.linkUrl.isNotBlank()) {
                        onOpenUrl(message.linkUrl)
                    }
                }
        ) {
            Row(
                modifier = Modifier.padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = InpPatrioticBlue,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.size(38.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.OpenInNew,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = message.linkTitle.ifBlank { "رابط خارجي" },
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontWeight = FontWeight.Bold
                        ),
                        color = InpPatrioticBlue,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = message.linkUrl,
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFF54656F),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = message.content,
            style = MaterialTheme.typography.bodyMedium,
            color = Color(0xFF111B21)
        )
    }
}

@Composable
private fun CallLogMessageContent(
    message: MessageEntity,
    onCallBack: () -> Unit
) {
    Surface(
        color = WhatsAppDarkGreen.copy(alpha = 0.08f),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onCallBack)
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    color = WhatsAppTealGreen,
                    shape = CircleShape,
                    modifier = Modifier.size(36.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = if (message.content.contains("مرئية"))
                                Icons.Default.Videocam else Icons.Default.Call,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = message.content,
                        style = MaterialTheme.typography.titleSmall,
                        color = Color(0xFF111B21)
                    )
                    Text(
                        text = "اضغط لإعادة الاتصال",
                        style = MaterialTheme.typography.labelSmall,
                        color = WhatsAppTealGreen
                    )
                }
            }
        }
    }
}

@Composable
private fun OfficialShareMessageContent(message: MessageEntity) {
    Surface(
        color = InpCrimsonRed.copy(alpha = 0.08f),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, InpCrimsonRed.copy(alpha = 0.35f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Campaign,
                    contentDescription = null,
                    tint = InpCrimsonRed,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = message.linkTitle.ifBlank { "بيان رسمي • حزب الهوية القومية العراقية" },
                    style = MaterialTheme.typography.labelLarge.copy(
                        fontWeight = FontWeight.Bold
                    ),
                    color = InpCrimsonRed
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = message.content,
                style = MaterialTheme.typography.bodyMedium,
                color = Color(0xFF111B21)
            )
        }
    }
}

@Composable
private fun AttachmentOptionItem(
    icon: ImageVector,
    label: String,
    bgColor: Color,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Surface(
            color = bgColor,
            shape = CircleShape,
            modifier = Modifier.size(54.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = Color.White,
                    modifier = Modifier.size(26.dp)
                )
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = Color(0xFF3B4A54)
        )
    }
}
