package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddComment
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.ChatCategory
import com.example.data.ChatRoomEntity
import com.example.data.SocialPlatform
import com.example.data.UserProfile
import com.example.ui.theme.InpCrimsonRed
import com.example.ui.theme.InpPatrioticBlue
import com.example.ui.theme.InstagramMagenta
import com.example.ui.theme.TikTokBlack
import com.example.ui.theme.WhatsAppBrightGreen
import com.example.ui.theme.WhatsAppDarkGreen
import com.example.ui.theme.WhatsAppTealGreen

@Composable
fun ChatsTabContent(
    rooms: List<ChatRoomEntity>,
    userProfile: UserProfile,
    selectedFilter: String,
    searchQuery: String,
    showNewRoomDialog: Boolean,
    onDismissNewRoomDialog: () -> Unit,
    onFilterSelected: (String) -> Unit,
    onOpenRoom: (ChatRoomEntity) -> Unit,
    onTogglePinRoom: (ChatRoomEntity) -> Unit,
    onStartVoiceCall: (ChatRoomEntity) -> Unit,
    onStartVideoCall: (ChatRoomEntity) -> Unit,
    onCreateNewRoom: (
        title: String,
        subtitle: String,
        category: ChatCategory,
        socialHandle: String,
        socialPlatform: SocialPlatform,
        membersCount: Int
    ) -> Unit
) {
    val filters = listOf(
        "ALL" to "الكل",
        ChatCategory.OFFICIAL_GROUP.name to "المجموعات الرسمية",
        ChatCategory.CADRE_GROUP.name to "غرف الكوادر",
        ChatCategory.DIRECT_CHAT.name to "المحادثات الخاصة"
    )

    val filteredRooms = remember(rooms, selectedFilter, searchQuery) {
        rooms.filter { room ->
            val matchesCategory = selectedFilter == "ALL" || room.category == selectedFilter
            val matchesQuery = searchQuery.isBlank() ||
                room.title.contains(searchQuery, ignoreCase = true) ||
                room.subtitle.contains(searchQuery, ignoreCase = true) ||
                room.lastMessagePreview.contains(searchQuery, ignoreCase = true) ||
                room.socialLinkHandle.contains(searchQuery, ignoreCase = true)
            matchesCategory && matchesQuery
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
            .testTag("chats_tab_content")
    ) {
        // Connected Social Identity & Filter Bar
        Surface(
            color = Color(0xFFF7F9FA),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(top = 8.dp, bottom = 6.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            color = if (userProfile.socialPlatform == SocialPlatform.TIKTOK)
                                TikTokBlack else InstagramMagenta,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = userProfile.socialPlatform.displayName,
                                color = Color.White,
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "${userProfile.fullName} (${userProfile.socialHandle})",
                            style = MaterialTheme.typography.labelLarge,
                            color = Color(0xFF111B21),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Surface(
                        color = InpCrimsonRed.copy(alpha = 0.12f),
                        shape = RoundedCornerShape(50)
                    ) {
                        Text(
                            text = userProfile.governorate,
                            color = InpCrimsonRed,
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
                        )
                    }
                }

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 14.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filters) { (key, label) ->
                        val selected = selectedFilter == key
                        FilterChip(
                            selected = selected,
                            onClick = { onFilterSelected(key) },
                            label = { Text(label) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = WhatsAppDarkGreen,
                                selectedLabelColor = Color.White
                            ),
                            shape = RoundedCornerShape(50)
                        )
                    }
                }
            }
        }

        HorizontalDivider(color = Color(0xFFECEFF1), thickness = 1.dp)

        if (filteredRooms.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Groups,
                        contentDescription = null,
                        tint = WhatsAppTealGreen,
                        modifier = Modifier.size(56.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "لا توجد محادثات مطابقة للبحث",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color(0xFF3B4A54)
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("chat_rooms_list"),
                contentPadding = PaddingValues(bottom = 88.dp)
            ) {
                items(filteredRooms, key = { it.id }) { room ->
                    WhatsAppChatRowItem(
                        room = room,
                        onClick = { onOpenRoom(room) },
                        onPinToggle = { onTogglePinRoom(room) },
                        onVoiceCall = { onStartVoiceCall(room) },
                        onVideoCall = { onStartVideoCall(room) }
                    )
                    HorizontalDivider(
                        modifier = Modifier.padding(start = 78.dp, end = 16.dp),
                        color = Color(0xFFF0F2F5),
                        thickness = 0.8.dp
                    )
                }
            }
        }
    }

    if (showNewRoomDialog) {
        NewPartyChatDialog(
            onDismiss = onDismissNewRoomDialog,
            onCreate = { title, subtitle, category, handle, platform, count ->
                onCreateNewRoom(title, subtitle, category, handle, platform, count)
                onDismissNewRoomDialog()
            }
        )
    }
}

@Composable
private fun WhatsAppChatRowItem(
    room: ChatRoomEntity,
    onClick: () -> Unit,
    onPinToggle: () -> Unit,
    onVoiceCall: () -> Unit,
    onVideoCall: () -> Unit
) {
    val avatarColor = remember(room.avatarColorHex) {
        try {
            Color(android.graphics.Color.parseColor(room.avatarColorHex))
        } catch (_: Exception) {
            WhatsAppDarkGreen
        }
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp)
            .testTag("chat_room_item_${room.id}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Avatar with official party logo or initial badge
        Box(contentAlignment = Alignment.BottomEnd) {
            Surface(
                modifier = Modifier.size(56.dp),
                shape = CircleShape,
                color = avatarColor,
                border = BorderStroke(1.5.dp, avatarColor.copy(alpha = 0.3f))
            ) {
                if (room.category == ChatCategory.OFFICIAL_GROUP.name) {
                    Image(
                        painter = painterResource(id = R.drawable.img_inp_party_logo),
                        contentDescription = room.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = "INP",
                            color = Color.White,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }
            }

            if (room.isOfficialVerified) {
                Surface(
                    shape = CircleShape,
                    color = Color.White,
                    modifier = Modifier.size(20.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Verified,
                        contentDescription = "حساب حزبي موثق",
                        tint = InpPatrioticBlue,
                        modifier = Modifier.padding(1.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.width(12.dp))

        // Center Content (Title, Handle, Last Message)
        Column(modifier = Modifier.weight(1f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = room.title,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold
                        ),
                        color = Color(0xFF111B21),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                Text(
                    text = room.lastMessageTime,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (room.unreadCount > 0) WhatsAppBrightGreen else Color(0xFF667781),
                    fontWeight = if (room.unreadCount > 0) FontWeight.Bold else FontWeight.Normal
                )
            }

            Spacer(modifier = Modifier.height(2.dp))

            // Social Handle & Category Pill
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = room.socialLinkHandle,
                    style = MaterialTheme.typography.labelSmall,
                    color = WhatsAppTealGreen
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "• ${room.membersCount} عضو",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFF8696A0)
                )
            }

            Spacer(modifier = Modifier.height(3.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = room.lastMessagePreview,
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (room.unreadCount > 0) Color(0xFF111B21) else Color(0xFF667781),
                    fontWeight = if (room.unreadCount > 0) FontWeight.SemiBold else FontWeight.Normal,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (room.isMuted) {
                        Icon(
                            imageVector = Icons.Default.VolumeOff,
                            contentDescription = "مكتوم",
                            tint = Color(0xFF8696A0),
                            modifier = Modifier
                                .size(16.dp)
                                .padding(end = 4.dp)
                        )
                    }
                    if (room.isPinned) {
                        IconButton(
                            onClick = onPinToggle,
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.PushPin,
                                contentDescription = "مثبت",
                                tint = WhatsAppTealGreen,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                    if (room.unreadCount > 0) {
                        Spacer(modifier = Modifier.width(4.dp))
                        Surface(
                            color = WhatsAppBrightGreen,
                            shape = CircleShape
                        ) {
                            Text(
                                text = room.unreadCount.toString(),
                                color = Color.White,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                ),
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }
        }

        // Quick Voice & Video Call Action Icons
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(
                onClick = onVoiceCall,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Call,
                    contentDescription = "اتصال صوتي",
                    tint = WhatsAppTealGreen,
                    modifier = Modifier.size(20.dp)
                )
            }
            IconButton(
                onClick = onVideoCall,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Videocam,
                    contentDescription = "اتصال مرئي",
                    tint = WhatsAppDarkGreen,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
private fun NewPartyChatDialog(
    onDismiss: () -> Unit,
    onCreate: (
        title: String,
        subtitle: String,
        category: ChatCategory,
        socialHandle: String,
        socialPlatform: SocialPlatform,
        membersCount: Int
    ) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var subtitle by remember { mutableStateOf("") }
    var socialHandle by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf(ChatCategory.CADRE_GROUP) }
    var selectedPlatform by remember { mutableStateOf(SocialPlatform.TIKTOK) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.AddComment,
                    contentDescription = null,
                    tint = WhatsAppDarkGreen
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "إنشاء مجموعة أو محادثة حزبية",
                    style = MaterialTheme.typography.titleMedium
                )
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("اسم المجموعة أو العضو") },
                    placeholder = { Text("مثال: مكتب تنظيم نينوى - INP") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = subtitle,
                    onValueChange = { subtitle = it },
                    label = { Text("الوصف التنظيمي") },
                    placeholder = { Text("التنسيق الميداني والإعلامي") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = socialHandle,
                    onValueChange = { socialHandle = it },
                    label = { Text("يوزر التيك توك أو إنستغرام (@handle)") },
                    placeholder = { Text("@inp.nineveh") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ChatCategory.entries.forEach { cat ->
                        FilterChip(
                            selected = selectedCategory == cat,
                            onClick = { selectedCategory = cat },
                            label = { Text(cat.labelAr, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SocialPlatform.entries.forEach { platform ->
                        FilterChip(
                            selected = selectedPlatform == platform,
                            onClick = { selectedPlatform = platform },
                            label = { Text(platform.displayName) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        onCreate(
                            title.trim(),
                            subtitle.ifBlank { "غرفة تواصل حزبية • العراق أولاً" },
                            selectedCategory,
                            socialHandle.ifBlank { "@inp.iraq" },
                            selectedPlatform,
                            if (selectedCategory == ChatCategory.DIRECT_CHAT) 2 else 45
                        )
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = WhatsAppDarkGreen)
            ) {
                Text("إنشاء وبدء المحادثة")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}
