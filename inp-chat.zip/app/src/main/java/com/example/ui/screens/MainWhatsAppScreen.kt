package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddComment
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EnhancedEncryption
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.ChatCategory
import com.example.data.ChatRoomEntity
import com.example.data.OfficialStatementEntity
import com.example.data.SocialPlatform
import com.example.data.UserProfile
import com.example.ui.MainWhatsAppTab
import com.example.ui.theme.InpCrimsonRed
import com.example.ui.theme.WhatsAppBrightGreen
import com.example.ui.theme.WhatsAppDarkGreen

@Composable
fun MainWhatsAppScreen(
    selectedTab: MainWhatsAppTab,
    chatRooms: List<ChatRoomEntity>,
    statements: List<OfficialStatementEntity>,
    userProfile: UserProfile,
    isSearchBarVisible: Boolean,
    searchQuery: String,
    selectedChatFilter: String,
    selectedStatementFilter: String,
    statusBanner: String?,
    onSelectTab: (MainWhatsAppTab) -> Unit,
    onToggleSearchBar: () -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onChatFilterSelected: (String) -> Unit,
    onStatementFilterSelected: (String) -> Unit,
    onOpenChatRoom: (ChatRoomEntity) -> Unit,
    onTogglePinRoom: (ChatRoomEntity) -> Unit,
    onStartVoiceCall: (ChatRoomEntity) -> Unit,
    onStartVideoCall: (ChatRoomEntity) -> Unit,
    onCreateNewRoom: (
        title: String,
        subtitle: String,
        category: ChatCategory,
        socialHandle: String,
        socialPlatform: SocialPlatform,
        membersCount: Int
    ) -> Unit,
    onPublishStatement: (
        title: String,
        category: String,
        content: String,
        isPinned: Boolean,
        referenceNumber: String
    ) -> Unit,
    onToggleStatementLike: (OfficialStatementEntity) -> Unit,
    onToggleStatementPin: (OfficialStatementEntity) -> Unit,
    onDeleteStatement: (OfficialStatementEntity) -> Unit,
    onShareStatementToRoom: (OfficialStatementEntity, ChatRoomEntity) -> Unit,
    onEditSocialAccount: () -> Unit,
    onUpdateProfile: (UserProfile, String?) -> Unit,
    onResetDemoData: () -> Unit
) {
    var showOverflowMenu by remember { mutableStateOf(false) }
    var showSecurityDialog by remember { mutableStateOf(false) }
    var showNewRoomDialog by remember { mutableStateOf(false) }
    var showPublishStatementDialog by remember { mutableStateOf(false) }

    val totalUnreadChats = remember(chatRooms) {
        chatRooms.sumOf { it.unreadCount }
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            // Classic WhatsApp Green Top Header + Tabs
            Surface(
                color = WhatsAppDarkGreen,
                shadowElevation = 4.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .windowInsetsPadding(WindowInsets.statusBars)
                ) {
                    // Header Title & Action Icons Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Image(
                                painter = painterResource(id = R.drawable.img_inp_icon_bubble_1793444590223),
                                contentDescription = "أيقونة INP Chat",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .border(1.5.dp, Color.White, CircleShape)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "INP Chat",
                                    color = Color.White,
                                    style = MaterialTheme.typography.titleLarge.copy(
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 21.sp
                                    )
                                )
                                Text(
                                    text = "حزب الهوية القومية العراقية",
                                    color = Color.White.copy(alpha = 0.82f),
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // Search Icon
                            IconButton(
                                onClick = onToggleSearchBar,
                                modifier = Modifier.testTag("header_search_button")
                            ) {
                                Icon(
                                    imageVector = if (isSearchBarVisible)
                                        Icons.Default.Close else Icons.Default.Search,
                                    contentDescription = "البحث",
                                    tint = Color.White
                                )
                            }

                            // Privacy & Security Shield Icon
                            IconButton(
                                onClick = { showSecurityDialog = true },
                                modifier = Modifier.testTag("header_security_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Security,
                                    contentDescription = "إعدادات الخصوصية والأمان",
                                    tint = WhatsAppBrightGreen
                                )
                            }

                            // 3-Dot Menu Options
                            Box {
                                IconButton(
                                    onClick = { showOverflowMenu = true },
                                    modifier = Modifier.testTag("header_menu_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.MoreVert,
                                        contentDescription = "خيارات القائمة",
                                        tint = Color.White
                                    )
                                }

                                DropdownMenu(
                                    expanded = showOverflowMenu,
                                    onDismissRequest = { showOverflowMenu = false }
                                ) {
                                    DropdownMenuItem(
                                        text = { Text("مجموعة حزبية جديدة") },
                                        onClick = {
                                            showOverflowMenu = false
                                            onSelectTab(MainWhatsAppTab.CHATS)
                                            showNewRoomDialog = true
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("نشر بيان أو تعميم رسمي") },
                                        onClick = {
                                            showOverflowMenu = false
                                            onSelectTab(MainWhatsAppTab.UPDATES)
                                            showPublishStatementDialog = true
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = {
                                            Text(
                                                if (userProfile.isLeadershipMode)
                                                    "إيقاف وضع قيادات الحزب"
                                                else
                                                    "تفعيل وضع قيادات الحزب"
                                            )
                                        },
                                        onClick = {
                                            showOverflowMenu = false
                                            onUpdateProfile(
                                                userProfile.copy(isLeadershipMode = !userProfile.isLeadershipMode),
                                                "تم تحديث وضع قيادات الحزب"
                                            )
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("تعديل يوزر تيك توك / إنستغرام") },
                                        onClick = {
                                            showOverflowMenu = false
                                            onEditSocialAccount()
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("إعدادات الخصوصية والأمان") },
                                        onClick = {
                                            showOverflowMenu = false
                                            onSelectTab(MainWhatsAppTab.SETTINGS)
                                        }
                                    )
                                }
                            }
                        }
                    }

                    // Expandable Search Bar inside Header
                    AnimatedVisibility(visible = isSearchBarVisible) {
                        Surface(
                            color = Color.White.copy(alpha = 0.14f),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            TextField(
                                value = searchQuery,
                                onValueChange = onSearchQueryChange,
                                placeholder = {
                                    Text(
                                        text = "ابحث في المجموعات، الأعضاء، أو البيانات الرسمية...",
                                        color = Color.White.copy(alpha = 0.75f),
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                },
                                singleLine = true,
                                colors = TextFieldDefaults.colors(
                                    focusedContainerColor = Color.Transparent,
                                    unfocusedContainerColor = Color.Transparent,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedIndicatorColor = Color.Transparent,
                                    unfocusedIndicatorColor = Color.Transparent
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("main_search_input")
                            )
                        }
                    }

                    // Three WhatsApp-style Main Tabs (المحادثات | البيانات والتعاميم | الإعدادات)
                    TabRow(
                        selectedTabIndex = selectedTab.ordinal,
                        containerColor = WhatsAppDarkGreen,
                        contentColor = Color.White,
                        indicator = { tabPositions ->
                            if (selectedTab.ordinal < tabPositions.size) {
                                TabRowDefaults.SecondaryIndicator(
                                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab.ordinal]),
                                    height = 3.5.dp,
                                    color = Color.White
                                )
                            }
                        }
                    ) {
                        MainWhatsAppTab.entries.forEach { tab ->
                            val isSelected = selectedTab == tab
                            Tab(
                                selected = isSelected,
                                onClick = { onSelectTab(tab) },
                                modifier = Modifier.testTag("tab_${tab.name.lowercase()}"),
                                text = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = tab.titleAr,
                                            style = MaterialTheme.typography.titleSmall.copy(
                                                fontWeight = if (isSelected)
                                                    FontWeight.Bold else FontWeight.Medium
                                            ),
                                            color = if (isSelected)
                                                Color.White else Color.White.copy(alpha = 0.75f)
                                        )
                                        if (tab == MainWhatsAppTab.CHATS && totalUnreadChats > 0) {
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Badge(
                                                containerColor = WhatsAppBrightGreen,
                                                contentColor = Color.White
                                            ) {
                                                Text(
                                                    text = totalUnreadChats.toString(),
                                                    modifier = Modifier.padding(horizontal = 2.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            )
                        }
                    }
                }
            }
        },
        floatingActionButton = {
            when (selectedTab) {
                MainWhatsAppTab.CHATS -> {
                    FloatingActionButton(
                        onClick = { showNewRoomDialog = true },
                        containerColor = WhatsAppBrightGreen,
                        contentColor = Color.White,
                        shape = CircleShape,
                        modifier = Modifier
                            .navigationBarsPadding()
                            .testTag("fab_new_chat")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AddComment,
                            contentDescription = "بدء محادثة أو مجموعة جديدة"
                        )
                    }
                }

                MainWhatsAppTab.UPDATES -> {
                    if (userProfile.isLeadershipMode) {
                        FloatingActionButton(
                            onClick = { showPublishStatementDialog = true },
                            containerColor = InpCrimsonRed,
                            contentColor = Color.White,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .navigationBarsPadding()
                                .testTag("fab_publish_statement")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Campaign,
                                    contentDescription = "نشر بيان رسمي"
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "نشر بيان رسمي",
                                    style = MaterialTheme.typography.labelLarge
                                )
                            }
                        }
                    }
                }

                MainWhatsAppTab.SETTINGS -> {}
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                MainWhatsAppTab.CHATS -> {
                    ChatsTabContent(
                        rooms = chatRooms,
                        userProfile = userProfile,
                        selectedFilter = selectedChatFilter,
                        searchQuery = searchQuery,
                        showNewRoomDialog = showNewRoomDialog,
                        onDismissNewRoomDialog = { showNewRoomDialog = false },
                        onFilterSelected = onChatFilterSelected,
                        onOpenRoom = onOpenChatRoom,
                        onTogglePinRoom = onTogglePinRoom,
                        onStartVoiceCall = onStartVoiceCall,
                        onStartVideoCall = onStartVideoCall,
                        onCreateNewRoom = onCreateNewRoom
                    )
                }

                MainWhatsAppTab.UPDATES -> {
                    UpdatesTabContent(
                        statements = statements,
                        chatRooms = chatRooms,
                        userProfile = userProfile,
                        selectedCategory = selectedStatementFilter,
                        searchQuery = searchQuery,
                        showPublishDialog = showPublishStatementDialog,
                        onOpenPublishDialog = { showPublishStatementDialog = true },
                        onDismissPublishDialog = { showPublishStatementDialog = false },
                        onSelectCategory = onStatementFilterSelected,
                        onToggleLeadershipMode = { enabled ->
                            onUpdateProfile(
                                userProfile.copy(isLeadershipMode = enabled),
                                if (enabled) "تم تفعيل وضع قيادات الحزب" else "تم إيقاف وضع قيادات الحزب"
                            )
                        },
                        onPublishStatement = onPublishStatement,
                        onToggleLike = onToggleStatementLike,
                        onTogglePin = onToggleStatementPin,
                        onDeleteStatement = onDeleteStatement,
                        onShareToChatRoom = onShareStatementToRoom
                    )
                }

                MainWhatsAppTab.SETTINGS -> {
                    SettingsTabContent(
                        userProfile = userProfile,
                        onEditSocialAccount = onEditSocialAccount,
                        onUpdateProfile = onUpdateProfile,
                        onResetDemoData = onResetDemoData
                    )
                }
            }

            // Floating Status Toast Banner at Bottom
            AnimatedVisibility(
                visible = !statusBanner.isNullOrBlank(),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(bottom = 18.dp, start = 20.dp, end = 20.dp)
            ) {
                Surface(
                    color = Color(0xFF1F2C34),
                    shape = RoundedCornerShape(50),
                    shadowElevation = 6.dp
                ) {
                    Text(
                        text = statusBanner ?: "",
                        color = Color.White,
                        style = MaterialTheme.typography.labelLarge,
                        modifier = Modifier.padding(horizontal = 18.dp, vertical = 10.dp)
                    )
                }
            }
        }
    }

    // Privacy & Security Quick Dialog from Top Header Icon
    if (showSecurityDialog) {
        AlertDialog(
            onDismissRequest = { showSecurityDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.EnhancedEncryption,
                        contentDescription = null,
                        tint = WhatsAppDarkGreen
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("مركز الخصوصية والأمان - INP Chat")
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "• الحساب المرتبط: ${userProfile.socialPlatform.displayName} (${userProfile.socialHandle})",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "• الصفة التنظيمية: ${userProfile.roleTitle}",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        text = "• حالة التشفير: جميع المحادثات الفردية والجماعية والمكالمات الصوتية والمرئية محمية بتشفير INP الكامل.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF54656F)
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showSecurityDialog = false
                        onSelectTab(MainWhatsAppTab.SETTINGS)
                    }
                ) {
                    Text("إدارة إعدادات الخصوصية")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSecurityDialog = false }) {
                    Text("إغلاق")
                }
            }
        )
    }
}
