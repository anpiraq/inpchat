package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EnhancedEncryption
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.SocialPlatform
import com.example.data.UserProfile
import com.example.ui.theme.InpCrimsonRed
import com.example.ui.theme.InstagramMagenta
import com.example.ui.theme.TikTokBlack
import com.example.ui.theme.WhatsAppBrightGreen
import com.example.ui.theme.WhatsAppDarkGreen

@Composable
fun SettingsTabContent(
    userProfile: UserProfile,
    onEditSocialAccount: () -> Unit,
    onUpdateProfile: (UserProfile, String?) -> Unit,
    onResetDemoData: () -> Unit
) {
    val context = LocalContext.current

    val wallpapers = listOf(
        "#ECE5DD" to "كلاسيكي واتساب",
        "#F3EFEA" to "رملي هادئ",
        "#E5F2EC" to "أخضر ناعم",
        "#E8EEF2" to "أزرق وطني"
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF4F6F8))
            .testTag("settings_tab_content"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Member Identity Card (TikTok / Instagram Connected Account)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_inp_party_logo),
                            contentDescription = "هوية العضو",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(68.dp)
                                .clip(CircleShape)
                                .border(2.dp, WhatsAppDarkGreen, CircleShape)
                        )
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = userProfile.fullName,
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Bold
                                ),
                                color = Color(0xFF111B21)
                            )
                            Text(
                                text = "${userProfile.roleTitle} • ${userProfile.governorate}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color(0xFF54656F)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    color = if (userProfile.socialPlatform == SocialPlatform.TIKTOK)
                                        TikTokBlack else InstagramMagenta,
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = "${userProfile.socialPlatform.displayName}: ${userProfile.socialHandle}",
                                        color = Color.White,
                                        style = MaterialTheme.typography.labelMedium,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    HorizontalDivider(color = Color(0xFFF0F2F5))
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = onEditSocialAccount,
                            colors = ButtonDefaults.buttonColors(containerColor = WhatsAppDarkGreen),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("edit_social_account_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("تعديل يوزر التواصل")
                        }

                        OutlinedButton(
                            onClick = {
                                val clean = userProfile.socialHandle.removePrefix("@")
                                val url = "${userProfile.socialPlatform.baseUrl}$clean"
                                try {
                                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                                } catch (_: Exception) {
                                }
                            },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.OpenInNew,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("فتح حسابي")
                        }
                    }
                }
            }
        }

        // 2. Organizational Permissions (Leadership Mode)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = null,
                            tint = InpCrimsonRed
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "الصلاحيات التنظيمية والقيادية",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    SettingsToggleRow(
                        title = "وضع قيادات الحزب (Leadership Mode)",
                        subtitle = "السماح بنشر وتثبيت وحذف البيانات الرسمية والتعاميم الحزبية",
                        checked = userProfile.isLeadershipMode,
                        onCheckedChange = {
                            onUpdateProfile(
                                userProfile.copy(isLeadershipMode = it),
                                if (it) "تم تفعيل وضع قيادات الحزب" else "تم إيقاف وضع قيادات الحزب"
                            )
                        }
                    )
                }
            }
        }

        // 3. Privacy & Security Settings
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = WhatsAppDarkGreen
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "إعدادات الخصوصية والأمان",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Surface(
                        color = Color(0xFFE8F5E9),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.EnhancedEncryption,
                                contentDescription = null,
                                tint = WhatsAppDarkGreen
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "جميع المحادثات والمكالمات والملفات محمية بتشفير INP الكامل بين أعضاء الحزب.",
                                style = MaterialTheme.typography.bodySmall,
                                color = WhatsAppDarkGreen
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    SettingsToggleRow(
                        title = "مؤشرات قراءة الرسائل (العلامة المزدوجة)",
                        subtitle = "إظهار علامة القراءة الزرقاء/الخضراء عند الاطلاع على الرسائل",
                        checked = userProfile.readReceiptsEnabled,
                        onCheckedChange = {
                            onUpdateProfile(
                                userProfile.copy(readReceiptsEnabled = it),
                                "تم تحديث إعدادات مؤشرات القراءة"
                            )
                        }
                    )

                    HorizontalDivider(color = Color(0xFFF0F2F5))

                    SettingsToggleRow(
                        title = "إخفاء آخر ظهور وحالة الاتصال",
                        subtitle = "عدم مشاركة وقت آخر تواجد لك في غرف المحادثات",
                        checked = userProfile.hideLastSeen,
                        onCheckedChange = {
                            onUpdateProfile(
                                userProfile.copy(hideLastSeen = it),
                                "تم تحديث خصوصية آخر ظهور"
                            )
                        }
                    )

                    HorizontalDivider(color = Color(0xFFF0F2F5))

                    SettingsToggleRow(
                        title = "حماية التطبيق ببصمة / رمز سري",
                        subtitle = "تأمين المحادثات الحزبية عند فتح التطبيق",
                        checked = userProfile.appLockEnabled,
                        onCheckedChange = {
                            onUpdateProfile(
                                userProfile.copy(appLockEnabled = it),
                                if (it) "تم تفعيل قفل الأمان للتطبيق" else "تم إلغاء قفل التطبيق"
                            )
                        }
                    )
                }
            }
        }

        // 4. Calm Chat Wallpaper Picker
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Palette,
                            contentDescription = null,
                            tint = WhatsAppDarkGreen
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "خلفية شاشة المحادثة الهادئة",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        wallpapers.forEach { (hex, label) ->
                            val color = Color(android.graphics.Color.parseColor(hex))
                            val isSelected = userProfile.chatWallpaperHex.equals(hex, ignoreCase = true)
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable {
                                        onUpdateProfile(
                                            userProfile.copy(chatWallpaperHex = hex),
                                            "تم تغيير خلفية المحادثة إلى: $label"
                                        )
                                    }
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(52.dp)
                                        .clip(CircleShape)
                                        .background(color)
                                        .border(
                                            width = if (isSelected) 3.dp else 1.dp,
                                            color = if (isSelected) WhatsAppDarkGreen else Color(0xFFB0BEC5),
                                            shape = CircleShape
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (isSelected) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = "محدد",
                                            tint = WhatsAppDarkGreen
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = label,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color(0xFF3B4A54)
                                )
                            }
                        }
                    }
                }
            }
        }

        // 5. Restore Initial Party Data
        item {
            OutlinedButton(
                onClick = onResetDemoData,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, InpCrimsonRed),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = null,
                    tint = InpCrimsonRed
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "استعادة المحادثات والبيانات الافتراضية للحزب",
                    color = InpCrimsonRed
                )
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun SettingsToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                color = Color(0xFF111B21)
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFF667781)
            )
        }
        Spacer(modifier = Modifier.width(10.dp))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = WhatsAppDarkGreen
            )
        )
    }
}
