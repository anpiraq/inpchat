package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AlternateEmail
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.LocationCity
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.SocialPlatform
import com.example.data.UserProfile
import com.example.ui.theme.InpCrimsonRed
import com.example.ui.theme.InstagramMagenta
import com.example.ui.theme.TikTokBlack
import com.example.ui.theme.WhatsAppBrightGreen
import com.example.ui.theme.WhatsAppDarkGreen

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SocialAuthScreen(
    initialProfile: UserProfile,
    onCompleteRegistration: (
        fullName: String,
        platform: SocialPlatform,
        handle: String,
        roleTitle: String,
        governorate: String,
        enableLeadership: Boolean
    ) -> Unit
) {
    var selectedPlatform by remember { mutableStateOf(initialProfile.socialPlatform) }
    var socialHandle by remember { mutableStateOf(initialProfile.socialHandle.removePrefix("@")) }
    var fullName by remember { mutableStateOf(initialProfile.fullName) }
    var selectedRole by remember { mutableStateOf(initialProfile.roleTitle) }
    var selectedGovernorate by remember { mutableStateOf(initialProfile.governorate) }
    var leadershipMode by remember { mutableStateOf(initialProfile.isLeadershipMode) }
    var handleError by remember { mutableStateOf(false) }

    val roles = listOf(
        "كادر متقدم - المكتب المركزي",
        "عضو عامل - INP",
        "قيادة مكتب محافظة",
        "منسق اللجنة الإعلامية"
    )

    val governorates = listOf(
        "بغداد", "البصرة", "نينوى", "الأنبار", "النجف",
        "كربلاء", "بابل", "ذي قار", "كركوك", "صلاح الدين", "ديالى"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF3F6F5)),
        contentAlignment = Alignment.TopCenter
    ) {
        // Top Header Accent Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(210.dp)
                .background(
                    Brush.verticalGradient(
                        listOf(WhatsAppDarkGreen, Color(0xFF0A473E))
                    )
                )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 560.dp)
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Brand Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier.padding(vertical = 8.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_inp_icon_bubble_1793444590223),
                    contentDescription = "شعار INP Chat",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(58.dp)
                        .clip(CircleShape)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "منصة INP Chat الرسمية",
                        color = Color.White,
                        style = MaterialTheme.typography.titleLarge
                    )
                    Text(
                        text = "حزب الهوية القومية العراقية • العراق أولاً",
                        color = Color.White.copy(alpha = 0.85f),
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Registration Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    Text(
                        text = "التسجيل عبر حساب تيك توك أو إنستغرام",
                        style = MaterialTheme.typography.titleLarge,
                        color = WhatsAppDarkGreen
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "أدخل يوزر حسابك في TikTok أو Instagram للانضمام الفوري إلى غرف محادثات الحزب وتلقي البيانات الرسمية.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFF54656F)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Social Platform Selector (TikTok vs Instagram)
                    Text(
                        text = "1. اختر منصة حسابك المرتبط:",
                        style = MaterialTheme.typography.titleSmall,
                        color = Color(0xFF111B21)
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        SocialPlatformOptionCard(
                            modifier = Modifier.weight(1f),
                            title = "تيك توك (TikTok)",
                            subtitle = "@tiktok",
                            accentColor = TikTokBlack,
                            badgeBg = Color(0xFF00F2FE),
                            isSelected = selectedPlatform == SocialPlatform.TIKTOK,
                            onClick = { selectedPlatform = SocialPlatform.TIKTOK },
                            testTag = "select_tiktok_button"
                        )
                        SocialPlatformOptionCard(
                            modifier = Modifier.weight(1f),
                            title = "إنستغرام (Instagram)",
                            subtitle = "@instagram",
                            accentColor = InstagramMagenta,
                            badgeBg = Color(0xFFFCE4EC),
                            isSelected = selectedPlatform == SocialPlatform.INSTAGRAM,
                            onClick = { selectedPlatform = SocialPlatform.INSTAGRAM },
                            testTag = "select_instagram_button"
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Social Username Input
                    OutlinedTextField(
                        value = socialHandle,
                        onValueChange = {
                            socialHandle = it.removePrefix("@").trim()
                            handleError = false
                        },
                        label = {
                            Text(
                                if (selectedPlatform == SocialPlatform.TIKTOK)
                                    "يوزر التيك توك (TikTok Username)"
                                else
                                    "يوزر الإنستغرام (Instagram Username)"
                            )
                        },
                        placeholder = { Text("inp.iraq") },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.AlternateEmail,
                                contentDescription = null,
                                tint = WhatsAppDarkGreen
                            )
                        },
                        isError = handleError,
                        supportingText = {
                            if (handleError) {
                                Text("يرجى إدخال يوزر تيك توك أو إنستغرام للمتابعة")
                            } else {
                                Text("سيظهر حسابك بصيغة @${socialHandle.ifBlank { "username" }} بجانب رسائلك")
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = WhatsAppDarkGreen,
                            focusedLabelColor = WhatsAppDarkGreen
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("social_username_input")
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Display Name Input
                    OutlinedTextField(
                        value = fullName,
                        onValueChange = { fullName = it },
                        label = { Text("الاسم الكامل أو اللقب التنظيمي") },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = null,
                                tint = WhatsAppDarkGreen
                            )
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = WhatsAppDarkGreen,
                            focusedLabelColor = WhatsAppDarkGreen
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("full_name_input")
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Organizational Role Chips
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Badge,
                            contentDescription = null,
                            tint = WhatsAppDarkGreen,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "الصفة التنظيمية في الحزب:",
                            style = MaterialTheme.typography.titleSmall
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        roles.forEach { role ->
                            FilterChip(
                                selected = selectedRole == role,
                                onClick = { selectedRole = role },
                                label = { Text(role) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = WhatsAppDarkGreen.copy(alpha = 0.14f),
                                    selectedLabelColor = WhatsAppDarkGreen
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Governorate Selection
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.LocationCity,
                            contentDescription = null,
                            tint = WhatsAppDarkGreen,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "المكتب / المحافظة:",
                            style = MaterialTheme.typography.titleSmall
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        governorates.forEach { gov ->
                            FilterChip(
                                selected = selectedGovernorate == gov,
                                onClick = { selectedGovernorate = gov },
                                label = { Text(gov) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = InpCrimsonRed.copy(alpha = 0.14f),
                                    selectedLabelColor = InpCrimsonRed
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Leadership Mode Toggle Card
                    Surface(
                        color = Color(0xFFF8F9FA),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, Color(0xFFE0E5E9)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Shield,
                                    contentDescription = null,
                                    tint = InpCrimsonRed,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "تفعيل وضع قيادات الحزب",
                                        style = MaterialTheme.typography.titleSmall,
                                        color = Color(0xFF111B21)
                                    )
                                    Text(
                                        text = "يتيح نشر وتثبيت البيانات الرسمية والتعاميم",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFF54656F)
                                    )
                                }
                            }
                            Switch(
                                checked = leadershipMode,
                                onCheckedChange = { leadershipMode = it },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = WhatsAppDarkGreen
                                ),
                                modifier = Modifier.testTag("leadership_mode_switch")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Submit Button
                    Button(
                        onClick = {
                            if (socialHandle.isBlank()) {
                                handleError = true
                            } else {
                                onCompleteRegistration(
                                    fullName,
                                    selectedPlatform,
                                    "@${socialHandle.removePrefix("@")}",
                                    selectedRole,
                                    selectedGovernorate,
                                    leadershipMode
                                )
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = WhatsAppDarkGreen,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("register_submit_button")
                    ) {
                        Text(
                            text = "دخول إلى INP Chat",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "حزب الهوية القومية العراقية (INP) • جميع المحادثات مشفرة ومحمية",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFF667781),
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun SocialPlatformOptionCard(
    modifier: Modifier = Modifier,
    title: String,
    subtitle: String,
    accentColor: Color,
    badgeBg: Color,
    isSelected: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .testTag(testTag),
        shape = RoundedCornerShape(14.dp),
        color = if (isSelected) accentColor.copy(alpha = 0.08f) else Color(0xFFF8F9FA),
        border = BorderStroke(
            width = if (isSelected) 2.dp else 1.dp,
            color = if (isSelected) accentColor else Color(0xFFDADEE2)
        )
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Surface(
                    color = accentColor,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = subtitle,
                        color = Color.White,
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
                if (isSelected) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "محدد",
                        tint = WhatsAppBrightGreen,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                color = Color(0xFF111B21),
                textAlign = TextAlign.Center
            )
        }
    }
}
