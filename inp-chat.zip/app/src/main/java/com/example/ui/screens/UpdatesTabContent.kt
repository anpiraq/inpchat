package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.ChatRoomEntity
import com.example.data.OfficialStatementEntity
import com.example.data.UserProfile
import com.example.ui.theme.InpCrimsonRed
import com.example.ui.theme.InpDeepRed
import com.example.ui.theme.InpPatrioticBlue
import com.example.ui.theme.WhatsAppBrightGreen
import com.example.ui.theme.WhatsAppDarkGreen
import com.example.ui.theme.WhatsAppTealGreen

@Composable
fun UpdatesTabContent(
    statements: List<OfficialStatementEntity>,
    chatRooms: List<ChatRoomEntity>,
    userProfile: UserProfile,
    selectedCategory: String,
    searchQuery: String,
    showPublishDialog: Boolean,
    onOpenPublishDialog: () -> Unit,
    onDismissPublishDialog: () -> Unit,
    onSelectCategory: (String) -> Unit,
    onToggleLeadershipMode: (Boolean) -> Unit,
    onPublishStatement: (
        title: String,
        category: String,
        content: String,
        isPinned: Boolean,
        referenceNumber: String
    ) -> Unit,
    onToggleLike: (OfficialStatementEntity) -> Unit,
    onTogglePin: (OfficialStatementEntity) -> Unit,
    onDeleteStatement: (OfficialStatementEntity) -> Unit,
    onShareToChatRoom: (OfficialStatementEntity, ChatRoomEntity) -> Unit
) {
    val categories = listOf(
        "الكل",
        "البرنامج السياسي",
        "تعميم تنظيمي",
        "بيان رسمي",
        "خبر عاجل"
    )

    var expandedProgramBanner by remember { mutableStateOf(false) }
    var statementToShare by remember { mutableStateOf<OfficialStatementEntity?>(null) }

    val filteredStatements = remember(statements, selectedCategory, searchQuery) {
        statements.filter { stmt ->
            val matchCat = selectedCategory == "الكل" || stmt.category == selectedCategory
            val matchSearch = searchQuery.isBlank() ||
                stmt.title.contains(searchQuery, ignoreCase = true) ||
                stmt.content.contains(searchQuery, ignoreCase = true) ||
                stmt.referenceNumber.contains(searchQuery, ignoreCase = true)
            matchCat && matchSearch
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF4F6F8))
            .testTag("updates_tab_content"),
        contentPadding = PaddingValues(bottom = 96.dp)
    ) {
        // 1. Hero Political Program & National Identity Banner
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                shape = RoundedCornerShape(20.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                listOf(InpCrimsonRed, InpDeepRed, Color(0xFF3A080C))
                            )
                        )
                        .padding(18.dp)
                ) {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.img_inp_party_logo),
                                    contentDescription = "شعار الحزب",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(60.dp)
                                        .clip(RoundedCornerShape(14.dp))
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Surface(
                                        color = Color.White.copy(alpha = 0.18f),
                                        shape = RoundedCornerShape(50)
                                    ) {
                                        Text(
                                            text = "الوثيقة الوطنية • العراق أولاً",
                                            color = Color.White,
                                            style = MaterialTheme.typography.labelSmall,
                                            modifier = Modifier.padding(
                                                horizontal = 10.dp,
                                                vertical = 3.dp
                                            )
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "البرنامج السياسي لحزب الهوية القومية العراقية - INP",
                                        color = Color.White,
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                }
                            }

                            IconButton(
                                onClick = { expandedProgramBanner = !expandedProgramBanner }
                            ) {
                                Icon(
                                    imageVector = if (expandedProgramBanner)
                                        Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                    contentDescription = "توسيع البرنامج السياسي",
                                    tint = Color.White
                                )
                            }
                        }

                        AnimatedVisibility(visible = expandedProgramBanner) {
                            Column(modifier = Modifier.padding(top = 12.dp)) {
                                HorizontalDivider(color = Color.White.copy(alpha = 0.2f))
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "• ترسيخ السيادة الوطنية العراقية الكاملة وحماية وحدة البلاد.\n" +
                                        "• بناء اقتصاد وطني إنتاجي يدعم الصناعة والزراعة والشباب.\n" +
                                        "• تعزيز الهوية القومية والوطنية الجامعة تحت راية (العراق أولاً).\n" +
                                        "• إصلاح مؤسسات الدولة وترسيخ سيادة القانون والعدالة الاجتماعية.",
                                    color = Color.White.copy(alpha = 0.94f),
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                        }
                    }
                }
            }
        }

        // 2. Leadership Mode Control Bar
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 4.dp),
                shape = RoundedCornerShape(16.dp),
                color = Color.White,
                border = BorderStroke(1.dp, Color(0xFFE0E5E9))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Surface(
                            color = if (userProfile.isLeadershipMode)
                                WhatsAppDarkGreen.copy(alpha = 0.14f)
                            else
                                Color(0xFFECEFF1),
                            shape = CircleShape,
                            modifier = Modifier.size(40.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Shield,
                                    contentDescription = null,
                                    tint = if (userProfile.isLeadershipMode)
                                        WhatsAppDarkGreen else Color(0xFF667781)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "وضع قيادات الحزب (النشر والتثبيت)",
                                style = MaterialTheme.typography.titleSmall,
                                color = Color(0xFF111B21)
                            )
                            Text(
                                text = if (userProfile.isLeadershipMode)
                                    "مفعّل حالياً • يمكنك إصدار البيانات وتثبيت التعاميم"
                                else
                                    "وضع القراءة والتفاعل للأعضاء",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF54656F)
                            )
                        }
                    }

                    Switch(
                        checked = userProfile.isLeadershipMode,
                        onCheckedChange = onToggleLeadershipMode,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = WhatsAppDarkGreen
                        ),
                        modifier = Modifier.testTag("updates_leadership_switch")
                    )
                }
            }
        }

        // 3. Category Filter Row + Publish Action
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 14.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(categories) { cat ->
                        val isSelected = selectedCategory == cat
                        FilterChip(
                            selected = isSelected,
                            onClick = { onSelectCategory(cat) },
                            label = { Text(cat) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = InpCrimsonRed,
                                selectedLabelColor = Color.White
                            ),
                            shape = RoundedCornerShape(50)
                        )
                    }
                }
            }
        }

        // 4. Statements & Circulars Cards
        items(filteredStatements, key = { it.id }) { statement ->
            OfficialStatementCard(
                statement = statement,
                isLeadershipMode = userProfile.isLeadershipMode,
                onLike = { onToggleLike(statement) },
                onPin = { onTogglePin(statement) },
                onDelete = { onDeleteStatement(statement) },
                onShare = { statementToShare = statement }
            )
        }
    }

    if (showPublishDialog) {
        PublishOfficialStatementDialog(
            onDismiss = onDismissPublishDialog,
            onPublish = { title, category, content, pinned, refNum ->
                onPublishStatement(title, category, content, pinned, refNum)
                onDismissPublishDialog()
            }
        )
    }

    statementToShare?.let { stmt ->
        ShareStatementToRoomDialog(
            statement = stmt,
            rooms = chatRooms,
            onDismiss = { statementToShare = null },
            onSelectRoom = { room ->
                onShareToChatRoom(stmt, room)
                statementToShare = null
            }
        )
    }
}

@Composable
private fun OfficialStatementCard(
    statement: OfficialStatementEntity,
    isLeadershipMode: Boolean,
    onLike: () -> Unit,
    onPin: () -> Unit,
    onDelete: () -> Unit,
    onShare: () -> Unit
) {
    val badgeColor = when (statement.category) {
        "البرنامج السياسي" -> InpCrimsonRed
        "تعميم تنظيمي" -> WhatsAppDarkGreen
        "خبر عاجل" -> Color(0xFFD84315)
        else -> InpPatrioticBlue
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 7.dp)
            .testTag("statement_card_${statement.id}"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = if (statement.isPinned) {
            BorderStroke(1.5.dp, badgeColor.copy(alpha = 0.45f))
        } else null
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Top Category & Pin Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = badgeColor,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = statement.category,
                            color = Color.White,
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                    if (statement.referenceNumber.isNotBlank()) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = statement.referenceNumber,
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFF667781)
                        )
                    }
                }

                if (statement.isPinned) {
                    Surface(
                        color = Color(0xFFFFF8E1),
                        shape = RoundedCornerShape(50),
                        border = BorderStroke(1.dp, Color(0xFFFFD54F))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.PushPin,
                                contentDescription = "مثبت",
                                tint = Color(0xFFF57F17),
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "مثبت للكوادر",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFFF57F17)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Title
            Text(
                text = statement.title,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold
                ),
                color = Color(0xFF111B21)
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Body Content
            Text(
                text = statement.content,
                style = MaterialTheme.typography.bodyMedium,
                color = Color(0xFF2E3B43)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Author & Timestamp
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Verified,
                        contentDescription = null,
                        tint = InpPatrioticBlue,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = "${statement.authorName} • ${statement.authorRole}",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFF54656F)
                    )
                }
                Text(
                    text = statement.publishedTime,
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFF8696A0)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = Color(0xFFF0F2F5))
            Spacer(modifier = Modifier.height(6.dp))

            // Action Buttons (Support, Share to Chat, Pin/Delete for Leaders)
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = onLike) {
                        Icon(
                            imageVector = if (statement.isLikedByMe)
                                Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "تأييد البيان",
                            tint = if (statement.isLikedByMe) InpCrimsonRed else Color(0xFF54656F),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "تأييد (${statement.likesCount})",
                            color = if (statement.isLikedByMe) InpCrimsonRed else Color(0xFF54656F),
                            style = MaterialTheme.typography.labelMedium
                        )
                    }

                    TextButton(onClick = onShare) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "مشاركة في المحادثات",
                            tint = WhatsAppTealGreen,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "تعميم في المحادثات",
                            color = WhatsAppTealGreen,
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                }

                if (isLeadershipMode) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = onPin,
                            modifier = Modifier.size(34.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.PushPin,
                                contentDescription = "تثبيت أو إلغاء التثبيت",
                                tint = if (statement.isPinned) WhatsAppDarkGreen else Color(0xFF8696A0),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        if (statement.id > 1L) {
                            IconButton(
                                onClick = onDelete,
                                modifier = Modifier.size(34.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DeleteOutline,
                                    contentDescription = "حذف البيان",
                                    tint = Color(0xFFD32F2F),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PublishOfficialStatementDialog(
    onDismiss: () -> Unit,
    onPublish: (
        title: String,
        category: String,
        content: String,
        isPinned: Boolean,
        referenceNumber: String
    ) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    var referenceNumber by remember { mutableStateOf("INP-2026-15") }
    var selectedCategory by remember { mutableStateOf("بيان رسمي") }
    var isPinned by remember { mutableStateOf(true) }

    val categories = listOf("بيان رسمي", "تعميم تنظيمي", "البرنامج السياسي", "خبر عاجل")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Campaign,
                    contentDescription = null,
                    tint = InpCrimsonRed
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "إصدار بيان أو تعميم رسمي - INP",
                    style = MaterialTheme.typography.titleMedium
                )
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(categories) { cat ->
                        FilterChip(
                            selected = selectedCategory == cat,
                            onClick = { selectedCategory = cat },
                            label = { Text(cat, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("عنوان البيان أو التعميم") },
                    placeholder = { Text("بيان صادر عن المكتب السياسي المركزي...") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("statement_title_input")
                )

                OutlinedTextField(
                    value = referenceNumber,
                    onValueChange = { referenceNumber = it },
                    label = { Text("رقم الصادر التنظيمي") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = content,
                    onValueChange = { content = it },
                    label = { Text("نص البيان الرسمي") },
                    placeholder = { Text("اكتب تفاصيل البيان أو التعميم الموجه للكوادر والجمهور...") },
                    minLines = 4,
                    maxLines = 6,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("statement_content_input")
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "تثبيت البيان في أعلى التبويب",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Switch(
                        checked = isPinned,
                        onCheckedChange = { isPinned = it }
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank() && content.isNotBlank()) {
                        onPublish(title.trim(), selectedCategory, content.trim(), isPinned, referenceNumber.trim())
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = InpCrimsonRed),
                modifier = Modifier.testTag("confirm_publish_statement_button")
            ) {
                Text("نشر وتعميم الآن")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}

@Composable
private fun ShareStatementToRoomDialog(
    statement: OfficialStatementEntity,
    rooms: List<ChatRoomEntity>,
    onDismiss: () -> Unit,
    onSelectRoom: (ChatRoomEntity) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "تعميم البيان في غرف المحادثات",
                style = MaterialTheme.typography.titleMedium
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "اختر المجموعة أو المحادثة لإرسال «${statement.title}»:",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF54656F)
                )
                rooms.forEach { room ->
                    OutlinedButton(
                        onClick = { onSelectRoom(room) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = room.title,
                                color = Color(0xFF111B21),
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Text(
                                text = "إرسال",
                                color = WhatsAppDarkGreen,
                                style = MaterialTheme.typography.labelMedium
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إغلاق")
            }
        }
    )
}
