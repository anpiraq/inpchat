package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Classic WhatsApp & INP Identity Colors
val WhatsAppDarkGreen = Color(0xFF075E54)
val WhatsAppTealGreen = Color(0xFF128C7E)
val WhatsAppBrightGreen = Color(0xFF25D366)
val OutgoingBubbleGreen = Color(0xFFD9FDD3)
val OutgoingBubbleClassic = Color(0xFFDCF8C6)
val IncomingBubbleWhite = Color(0xFFFFFFFF)
val ClassicChatWallpaper = Color(0xFFECE5DD)
val CalmSandWallpaper = Color(0xFFF3EFEA)
val CalmMintWallpaper = Color(0xFFE5F2EC)
val CalmSlateWallpaper = Color(0xFFE8EEF2)

// Iraqi National Identity Party (INP) Colors (matching uploaded emblem)
val InpCrimsonRed = Color(0xFF8B1A20)
val InpDeepRed = Color(0xFF590D12)
val InpPatrioticBlue = Color(0xFF1D63B8)
val InpLightBlue = Color(0xFF5CA0E6)
val InpGoldAccent = Color(0xFFD4AF37)
val InpPureWhite = Color(0xFFFFFFFF)

// Social Platform Accent Colors
val TikTokBlack = Color(0xFF111111)
val TikTokCyan = Color(0xFF00F2FE)
val TikTokRed = Color(0xFFFE0979)
val InstagramMagenta = Color(0xFFE1306C)
val InstagramOrange = Color(0xFFF77737)

// Dark Theme Surface Colors
val DarkHeaderGreen = Color(0xFF1F2C34)
val DarkBackground = Color(0xFF111B21)
val DarkSurface = Color(0xFF202C33)
val DarkOutgoingBubble = Color(0xFF005C4B)
val DarkIncomingBubble = Color(0xFF202C33)
