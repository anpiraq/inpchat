package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

private val DarkColorScheme = darkColorScheme(
    primary = WhatsAppTealGreen,
    onPrimary = Color.White,
    primaryContainer = WhatsAppDarkGreen,
    onPrimaryContainer = Color.White,
    secondary = WhatsAppBrightGreen,
    onSecondary = Color.Black,
    tertiary = InpCrimsonRed,
    onTertiary = Color.White,
    background = DarkBackground,
    onBackground = Color(0xFFE9EDEF),
    surface = DarkSurface,
    onSurface = Color(0xFFE9EDEF),
    surfaceVariant = Color(0xFF2A3942),
    onSurfaceVariant = Color(0xFF8696A0)
)

private val LightColorScheme = lightColorScheme(
    primary = WhatsAppDarkGreen,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD8F3DC),
    onPrimaryContainer = WhatsAppDarkGreen,
    secondary = WhatsAppTealGreen,
    onSecondary = Color.White,
    secondaryContainer = OutgoingBubbleClassic,
    onSecondaryContainer = Color(0xFF0A332C),
    tertiary = InpCrimsonRed,
    onTertiary = Color.White,
    background = Color(0xFFF7F8FA),
    onBackground = Color(0xFF111B21),
    surface = Color.White,
    onSurface = Color(0xFF111B21),
    surfaceVariant = Color(0xFFF0F2F5),
    onSurfaceVariant = Color(0xFF54656F)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}
