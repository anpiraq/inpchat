package com.example.util

import android.content.Context
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import java.io.File

class VoiceAudioHelper(private val context: Context) {

    private var mediaRecorder: MediaRecorder? = null
    private var mediaPlayer: MediaPlayer? = null
    private var currentOutputFile: File? = null
    var isUsingRealHardwareRecorder: Boolean = false
        private set

    fun startRecording(): String {
        stopRecordingSafely()
        val file = File(context.cacheDir, "inp_voice_${System.currentTimeMillis()}.m4a")
        currentOutputFile = file

        return try {
            val recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(context)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC)
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            recorder.setOutputFile(file.absolutePath)
            recorder.prepare()
            recorder.start()
            mediaRecorder = recorder
            isUsingRealHardwareRecorder = true
            file.absolutePath
        } catch (e: Exception) {
            // In browser streaming emulator without physical mic hardware, fallback gracefully
            isUsingRealHardwareRecorder = false
            mediaRecorder = null
            "simulated_voice://${System.currentTimeMillis()}"
        }
    }

    fun stopRecording(): String {
        val path = if (isUsingRealHardwareRecorder) {
            currentOutputFile?.absolutePath ?: ""
        } else {
            "simulated_voice://${System.currentTimeMillis()}"
        }
        stopRecordingSafely()
        return path
    }

    private fun stopRecordingSafely() {
        try {
            mediaRecorder?.apply {
                stop()
                release()
            }
        } catch (_: Exception) {
        } finally {
            mediaRecorder = null
        }
    }

    fun playAudioIfRealFile(
        uriOrPath: String,
        onCompletion: () -> Unit
    ): Boolean {
        stopPlayback()
        if (uriOrPath.isBlank() || uriOrPath.startsWith("simulated_voice://")) {
            return false
        }
        val file = File(uriOrPath)
        if (!file.exists() || file.length() == 0L) {
            return false
        }
        return try {
            mediaPlayer = MediaPlayer().apply {
                setDataSource(file.absolutePath)
                setOnCompletionListener {
                    onCompletion()
                }
                prepare()
                start()
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    fun stopPlayback() {
        try {
            mediaPlayer?.apply {
                if (isPlaying) stop()
                release()
            }
        } catch (_: Exception) {
        } finally {
            mediaPlayer = null
        }
    }
}
